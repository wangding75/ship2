"""Producer preservation/differential audit; read-only unless --record.

Does not import the independent reviewer's probe or change old artifacts.
"""
import argparse
import ast
import difflib
import hashlib
import json
import sys
import types
import zipfile
from datetime import datetime, timezone
from prepare_candidate import ROOT, CANDIDATE, AUTHOR, RUN
from protocol_model import ProtocolModel

ARCH=ROOT/'docs/architecture'
BASE=ARCH/'rework2/input/S1-T02-architecture-v1.0.1.zip'
EXPECTED='c2aeedd58af2bdae22f43f401ec2a1173e04f61e10a7c277ee633891177ffb1e'
def sha(data):return hashlib.sha256(data).hexdigest()
def parsed(data):return json.loads(data.decode('utf-8-sig'))
def tests(data):
    tree=ast.parse(data)
    return {c.name+'.'+f.name:ast.dump(f,include_attributes=False)
            for c in tree.body if isinstance(c,ast.ClassDef)
            for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_')}

def race(model,moving,fields):
    m=model()
    if moving:
        assert m.resolve(m.request(1,(100.,0.)))
        m.observe_tick((1.,0.),5.)
        for field in fields:setattr(m,field,field+'-B')
    target=(101.,0.) if moving else (100.,0.)
    token=m.request(2 if moving else 1,target)
    for field in fields:setattr(m,field,field+'-C')
    new=m.request(3,target)
    stale_resolved=m.resolve(token)
    retry=m.request(4,target)
    accepted=m.resolve(new)
    return {'state_before':'Moving' if moving else 'Idle','fields':list(fields),
            'old_token':vars(token),'new_token':vars(new),'same_token':new is token,
            'retry_is_new':retry is new,'old_resolved':stale_resolved,
            'new_resolved':accepted,'active_target':m.target,
            'active_map_sha':m.active_map_sha,'active_profile_sha':m.active_profile_sha,
            'expected_behavior':new is not token and not stale_resolved and accepted and retry is new}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--record',action='store_true');args=parser.parse_args()
    assert sha(BASE.read_bytes())==EXPECTED
    report={'candidate_ref':CANDIDATE,'producer_agent_uuid':AUTHOR,'producer_run_id':RUN,
            'record_kind':'PRODUCER_AUDIT_NOT_INDEPENDENT_ACCEPTANCE',
            'executed_utc':datetime.now(timezone.utc).isoformat(),'checks':[]}
    def check(name,detail):report['checks'].append({'id':name,'status':'PASS','evidence':detail})
    with zipfile.ZipFile(BASE) as old:
        manifest=old.read('docs/architecture/SHA256SUMS.txt').decode().splitlines()
        for line in manifest:
            digest,name=line.split('  ',1);assert sha(old.read(name))==digest
        assert len(manifest)==62 and len(old.namelist())==63
        check('original_v101_zip_and_manifest',{'zip_sha256':EXPECTED,'manifest_entries':len(manifest)})
        changed=[];same=[];diff=[]
        permitted={
            'docs/architecture/'+n for n in (
                'ADR-001-foundation.md','ADR-002-navigation.md','README.md','CHANGELOG.md',
                'candidate.json','traceability.json','interaction-recovery.md',
                'evidence/developer-notes.md','evidence/developer-validation.json',
                'evidence/developer-validation.log','evidence/input-manifest.json','evidence/runtime.json')}
        permitted.update('prototypes/architecture/'+n for n in ('protocol_model.py','verify.py','prepare_candidate.py','package.py'))
        permitted.update('specs/interfaces/'+n for n in ('contract.json','data.schema.json','examples/move-command.json','module-api.md'))
        for name in old.namelist():
            if name=='docs/architecture/SHA256SUMS.txt':continue
            current=(ROOT/name).read_bytes();prior=old.read(name)
            if current==prior:same.append(name)
            else:
                assert name in permitted,('UNEXPECTED_CHANGE',name)
                changed.append({'path':name,'before_sha256':sha(prior),'after_sha256':sha(current)})
                diff.extend(difflib.unified_diff(prior.decode('utf-8-sig').splitlines(True),
                            current.decode('utf-8-sig').splitlines(True),fromfile='v1.0.1/'+name,tofile='v1.0.2/'+name))
        check('all_original_members_preserved',{'unchanged_count':len(same),'unchanged':same,'changed':changed,'missing':[]})
        assert all(n in same for n in old.namelist() if n.startswith(('docs/architecture/inputs/','docs/architecture/rework-inputs/')))
        check('immutable_inputs_and_ship14_fail',{'all_input_bytes_unchanged':True})
        for name in ('t02-acc-a04-review-record.json','a04-probe-report.json'):
            data=(ARCH/'rework2/input'/name).read_bytes()
            obj=parsed(data)
            if name.startswith('t02-'):
                assert obj['verdict']=='FAIL' and obj['artifact_sha256']==EXPECTED
            else:assert obj['zip_sha256']==EXPECTED
            check('ship16_original_'+name,{'sha256':sha(data),'preserved_verdict':'FAIL'})
        current_tests=tests((ROOT/'prototypes/architecture/verify.py').read_bytes())
        previous_tests=tests(old.read('prototypes/architecture/verify.py'))
        assert len(previous_tests)==38 and len(current_tests)==48
        assert all(current_tests.get(k)==v for k,v in previous_tests.items())
        with zipfile.ZipFile(ARCH/'rework-inputs/S1-T02-architecture-v1.0.0.zip') as first:
            first_tests=tests(first.read('prototypes/architecture/verify.py'))
        assert len(first_tests)==33 and all(current_tests.get(k)==v for k,v in first_tests.items())
        check('original_38_and_33_test_AST',{'original_38_unchanged':38,'original_33_unchanged':33,
                                           'added':sorted(set(current_tests)-set(previous_tests))})
        previous=parsed(old.read('specs/interfaces/contract.json'))
        current=parsed((ROOT/'specs/interfaces/contract.json').read_bytes())
        changed_version=current['architecture_decisions']['already_active_binding']['changed_version']
        normalized=json.loads(json.dumps(current))
        normalized['candidate_ref']=previous['candidate_ref']
        normalized['interface_version']=previous['interface_version']
        normalized['architecture_decisions']['already_active_binding']['changed_version']=previous['architecture_decisions']['already_active_binding']['changed_version']
        assert normalized==previous
        assert 'pending.map_sha==map_sha' in changed_version and 'pending.profile_sha==profile_sha' in changed_version
        check('interface_only_version_and_pending_rule_changed',{'frozen_parameters_unchanged':True,'windows_effective':current['windows_amendment']['effective'],'t03_released':current['t03_released']})
        for name in ('specs/interfaces/data.schema.json','specs/interfaces/examples/move-command.json'):
            assert parsed((ROOT/name).read_bytes().replace(b'1.0.2',b'1.0.1'))==parsed(old.read(name))
        check('DTO_schema_and_example_structure_unchanged',{'interface_version':'S1-INTERFACES/1.0.2','snapshot_version':'1.0.0'})
        module=types.ModuleType('_old_v101_model');sys.modules[module.__name__]=module
        exec(compile(old.read('prototypes/architecture/protocol_model.py'),'old-v1.0.1/protocol_model.py','exec'),module.__dict__)
        cases=[]
        for moving in (False,True):
            for fields in (('map_sha',),('profile_sha',),('map_sha','profile_sha')):
                before=race(module.ProtocolModel,moving,fields);after=race(ProtocolModel,moving,fields)
                assert not before['expected_behavior'] and after['expected_behavior']
                cases.append({'before':before,'after':after})
        check('six_version_races_old_fails_new_passes',cases)
        # Only the pending condition may change in production reference logic.
        expected=old.read('prototypes/architecture/protocol_model.py').decode().replace(
            'if self.pending and self.pending.target == target:',
            'if (self.pending and self.pending.target == target and\n                self.pending.map_sha == self.map_sha and\n                self.pending.profile_sha == self.profile_sha):')
        assert (ROOT/'prototypes/architecture/protocol_model.py').read_text(encoding='utf-8')==expected
        check('only_pending_condition_changed',{'heading_function_and_all_other_protocol_code':'byte-equivalent after newline normalization'})
    report['status']='PASS'
    report['limits']={'independent_acceptance':'NOT_RUN','csharp_unity_devices_runtime':'NOT_RUN','windows_final_contract':'BLOCKED'}
    if args.record:
        (ARCH/'rework2/audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        (ARCH/'rework2/source.diff').write_text(''.join(diff),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
