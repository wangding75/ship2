"""Create and verify the delivery archive. Not a deployment, Gate, or build tool.

Only reads/writes T02 allowed directories. Package content is fixed by an explicit
allowlist; no environment files, credentials, runtime sessions or agent config.
"""
import argparse
import hashlib
import json
import pathlib
import sys
import zipfile
from datetime import datetime, timezone
from prepare_candidate import CANDIDATE, INTERFACE, AUTHOR, RUN

ROOT=pathlib.Path(__file__).resolve().parents[2]
ARCH=ROOT/'docs/architecture'
OUTPUT=ARCH/'delivery'
SUMS=ARCH/'SHA256SUMS.txt'
ZIP_NAME='S1-T02-architecture-v1.0.2.zip'


def sha(data):return hashlib.sha256(data).hexdigest()


def payload_files():
    files=[]
    for relative in ('docs/architecture','specs/interfaces','prototypes/architecture'):
        for path in (ROOT/relative).rglob('*'):
            if not path.is_file() or path==SUMS or OUTPUT in path.parents or '__pycache__' in path.parts:
                continue
            if path.suffix in ('.pyc','.pyo'):
                continue
            if path.is_symlink() or not path.resolve().is_relative_to((ROOT/relative).resolve()):
                raise ValueError(f'UNSAFE_PATH {path}')
            files.append(path)
    return sorted(files,key=lambda p:p.relative_to(ROOT).as_posix())


def verify_directory():
    expected={}
    for line in SUMS.read_text(encoding='utf-8').splitlines():
        digest,name=line.split('  ',1)
        if name in expected:raise ValueError('DUPLICATE_ENTRY')
        path=(ROOT/name).resolve()
        if not path.is_relative_to(ROOT):raise ValueError('PATH_TRAVERSAL')
        expected[name]=digest
        if sha(path.read_bytes())!=digest:raise ValueError('HASH_MISMATCH '+name)
    actual={p.relative_to(ROOT).as_posix() for p in payload_files()}
    if actual!=set(expected):raise ValueError('MANIFEST_INCOMPLETE')
    return expected


def verify_zip(path,expected):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        wanted=set(expected)|{SUMS.relative_to(ROOT).as_posix()}
        if len(names)!=len(set(names)) or set(names)!=wanted:raise ValueError('ZIP_CONTENT_MISMATCH')
        for name,digest in expected.items():
            if sha(z.read(name))!=digest:raise ValueError('ZIP_HASH_MISMATCH '+name)
        if z.read(SUMS.relative_to(ROOT).as_posix())!=SUMS.read_bytes():raise ValueError('MANIFEST_BYTES_CHANGED')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--verify',action='store_true');args=parser.parse_args()
    if args.verify:
        expected=verify_directory()
        if (OUTPUT/ZIP_NAME).exists():verify_zip(OUTPUT/ZIP_NAME,expected)
        print(f'PASS: {len(expected)} files match complete SHA256 manifest; '+
              ('archive bytes also verified.' if (OUTPUT/ZIP_NAME).exists() else 'archive not present in extracted payload.'))
        return
    OUTPUT.mkdir(parents=True,exist_ok=True)
    files=payload_files()
    SUMS.write_text(''.join(f'{sha(p.read_bytes())}  {p.relative_to(ROOT).as_posix()}\n' for p in files),encoding='utf-8')
    archive=OUTPUT/ZIP_NAME
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files+[SUMS]:
            # Fixed archive timestamps make a given set of bytes reproducible.
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,11,6,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,p.read_bytes())
    expected=verify_directory();verify_zip(archive,expected)
    record={
        'candidate_ref':CANDIDATE,'interface_version':INTERFACE,
        'producer_agent_uuid':AUTHOR,
        'producer_run_id':RUN,
        'candidate_commit':'NOT_APPLICABLE_NO_GIT',
        'archive_filename':ZIP_NAME,'archive_sha256':sha(archive.read_bytes()),'archive_bytes':archive.stat().st_size,
        'manifest_filename':'SHA256SUMS.txt','manifest_sha256':sha(SUMS.read_bytes()),'payload_file_count':len(expected),
        'interface_sha256':sha((ROOT/'specs/interfaces/contract.json').read_bytes()),
        'contract_sha256':sha((ARCH/'inputs/t02-contract-v1.json').read_bytes()),
        'developer_test_version':'S1-T02-DEV/1.0.2',
        'developer_test_sha256':sha((ROOT/'prototypes/architecture/verify.py').read_bytes()),
        'rework_audit_sha256':sha((ARCH/'rework2/audit.json').read_bytes()),
        'packaging_validation':{'status':'PASS','checks':['complete manifest','per-file hashes','zip member set','zip payload hashes','manifest byte equality']},
        'acceptance_status':'NOT_RUN','reviewer_role':'A04','t03_released':False,
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'budget_observation':{
            'run_started_utc':'2026-11-07T03:10:49Z',
            'elapsed_seconds_at_packaging':(datetime.now(timezone.utc)-datetime(2026,11,7,3,10,49,tzinfo=timezone.utc)).total_seconds(),
            'max_run_minutes':120,'max_cost_cny':None,'observed_cost_cny':None,'business_repair_attempt':2
        },
        'self_hash_policy':'SHA256SUMS excludes itself; delivery.json is external and binds ZIP+manifest; no circular hash claim'
    }
    (OUTPUT/'delivery.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
