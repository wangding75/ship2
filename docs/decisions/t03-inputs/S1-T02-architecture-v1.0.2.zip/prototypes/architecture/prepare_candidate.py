"""Materialize versioned T02 data from immutable, hash-bound attachments."""
import hashlib
import json
import os
import pathlib
import platform
import subprocess
import shutil
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[2]
INPUT = ROOT/'docs/architecture/inputs'
AUTHOR = 'c7c6d8e7-11db-4f0b-b31c-a975ad2fc956'
RUN = '01a1b3fc-c47f-7e87-b7af-d37e32a2ca27'
CANDIDATE = 'S1-T02-CANDIDATE-v1.0.2-20261107'
INTERFACE = 'S1-INTERFACES/1.0.2'
EXPECTED = {
 't02-contract-v1.json': 'b331e573b1b63353517d1cec16efb2040c447239ad5c747df286affe1bed7a32',
 'S1-T01-product-specs-v1.2.zip': '4cf141de3796dc0b2232a56a3fd6925559b9b538c66f8a3e75e1ff8348c52b37',
 't01-rework1-acc-a02-review-record.json': '699883cf2c2d5aace56a47066858c7bdda8d93e545566e652926e2889d2763e0',
 't00-specs-verified.zip': '870ee7637dee62bfea3f528c84193fb455a6cea1f00c87ffc798b9dae39f0215',
 'project_inputs_20261106_registered.json': '03280271aadd21e89806f1b3d69924369f9856ad8f215a44d0a027e8c003cf2c',
 'figure04_ocean.png': '47778e452a519f6482abfee15cdab3e202a3475f3186fac99c507693eb4cb0b2',
 'windows-amendment-v2-draft.zip': '58d8745c10e8583a76648bd6e0e2a13df6499567e61b0b4e74f14056b33fd286',
 't01-acceptance-routing.json': 'c88f809996b50573fa4991511e2d8ededcb1b7231fdab401eb95869f43eb6e12',
 't02-contract-acc-a02-review-record.json': 'a19c8b731236bf81de022134c969b2efc2979a1219df3927b316ad8b656da3d7'
}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def dump(relative, data):
    path = ROOT/relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def main():
    inputs = []
    for name, expected in EXPECTED.items():
        f = INPUT/name
        actual = hashlib.sha256(f.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f'INPUT_HASH_MISMATCH: {name}')
        inputs.append({'path': f.relative_to(ROOT).as_posix(), 'sha256': actual, 'size_bytes': f.stat().st_size})
    matrix = load(INPUT/'S1-T01-product-specs-v1.2/docs/product/S1_acceptance_traceability_matrix.json')
    frozen = matrix['frozen_parameters']
    dump('specs/interfaces/contract.json', {
        'interface_version': INTERFACE, 'candidate_ref': CANDIDATE,
        'status': 'CANDIDATE_PENDING_A04', 'product_spec_version': 'v1.2.0',
        'product_source_sha': EXPECTED['S1-T01-product-specs-v1.2.zip'],
        'frozen_parameters_verbatim': frozen,
        'architecture_decisions': {
            'coordinate_system': {'plane': 'XZ', 'up': '+Y', 'north': '+Z', 'starboard': '+X',
                'bounds_x_m': [-1024,1024], 'bounds_z_m': [-1024,1024], 'water_y_m': 0,
                'units_per_metre': 1, 'heading_zero': '+Z', 'heading_90': '+X', 'chunk_size_m': 256},
            'fixed_tick_hz': 50, 'fixed_dt_s': .02, 'single_navigation_state_source': True,
            'shortest_heading_delta': {
                'range': '(-180,180]', 'half_turn_deg': 180,
                'definition': 'd=EuclideanMod(EuclideanMod(to,360)-EuclideanMod(from,360),360); return d-360 if d>180 else d',
                'csharp_remainder': 'Normalize negative remainder before using it as Euclidean modulo',
                'pinned_examples': [{'from':0,'to':180,'delta':180},{'from':350,'to':10,'delta':20}]},
            'already_active_binding': {
                'capture': 'Successful goal acceptance binds active_map_sha and active_profile_sha from the validated plan token',
                'condition': 'Moving AND distance<=0.25*R_nav AND active_map_sha==map_sha AND active_profile_sha==profile_sha',
                'changed_version': 'Request a new plan; do not return ALREADY_ACTIVE using the old path. Merge same-target pending only when BOTH pending.map_sha==map_sha AND pending.profile_sha==profile_sha; otherwise invalidate the old token, increment generation and issue a token bound to current hashes, including Idle before acceptance. Stale resolves must fail.',
                'clear': 'Goal removal, Stop, session restore',
                'pending_far_target_on_near_click': 'Unchanged: ALREADY_ACTIVE does not cancel the pending far target'},
            'illegal_target_while_moving': 'Stopping_then_Blocked',
            'restore_mode': 'SAFE_IDLE', 'state_values': ['Idle','Moving','Stopping','Arrived','Blocked'],
            'geometric_reasons': ['TARGET_ON_LAND','CLEARANCE_INSUFFICIENT','NO_PATH_FOUND','OUT_OF_BOUNDS'],
            'arrival_near_stationary_exception': 'T01_TR02',
            'runtime_ui': 'uGUI', 'input': 'com.unity.inputsystem', 'render_pipeline': 'URP',
            'editor_selected_owner_report': '6000.6.6f1',
            'resolved_versions': {'urp': None, 'input_system': None, 'ugui': None, 'test_framework': None, 'unity_mcp_commit': None},
            'version_lock_owner': 'A14_T03',
            'wake_technical_defaults': {'sample_hz':10, 'moving_lifetime_s':6, 'stopped_fade_s':4, 'slots_per_ship':64, 'ships':30}
        },
        'windows_amendment': {'effective': False, 'status':'BLOCKED',
            'owner_authorized_platform':'Windows-only', 'resolution':[1920,1080],
            'minimum_fps':30, 'p95_max_ms':33.3,
            'memory_counter':None,'memory_threshold':None,'memory_growth_rule':None,
            'quality_settings':None,'aspect_20_9_decision':None,
            'recovery':'Owner parameters -> A00 complete amendment -> A02 G14; T03 also requires T02 independent PASS'},
        'figure04_unknowns': {k:None for k in ('hud_elements_in_figure04','port_landmark_architecture_in_figure04','three_ship_types_lineup_in_figure04')},
        'runtime_acceptance': 'NOT_RUN', 't03_released': False
    })
    refs = {
      1:['evidence/runtime.json'], 2:['README.md'],
      3:['ADR-001-foundation.md','asset-contract.md'],4:['asset-contract.md'],5:['asset-contract.md'],
      6:['asset-contract.md','interaction-recovery.md'],7:['asset-contract.md'],8:['ADR-002-navigation.md'],
      9:['ADR-002-navigation.md'],10:['interaction-recovery.md'],11:['ADR-002-navigation.md'],
      12:['ADR-002-navigation.md'],13:['ADR-002-navigation.md'],14:['ADR-002-navigation.md'],
      15:['ADR-002-navigation.md'],16:['ADR-002-navigation.md','asset-contract.md'],
      17:['../../specs/interfaces/module-api.md'],18:['interaction-recovery.md'],19:['interaction-recovery.md'],
      20:['interaction-recovery.md'],21:['interaction-recovery.md'],22:['ADR-001-foundation.md','gate-lease-protocol.md'],
      23:['asset-contract.md','gate-lease-protocol.md'],24:['gate-lease-protocol.md'],25:['gate-lease-protocol.md'],26:['README.md','gate-lease-protocol.md']
    }
    dump('docs/architecture/traceability.json', {
       'candidate_ref':CANDIDATE,'source_matrix_sha256':hashlib.sha256((INPUT/'S1-T01-product-specs-v1.2/docs/product/S1_acceptance_traceability_matrix.json').read_bytes()).hexdigest(),
       'entries':[{'source_requirement':r,'architecture_refs':refs[i], 'this_candidate_runtime_verdict':'NOT_RUN'} for i,r in enumerate(matrix['requirements'],1)],
       'task_acceptance':{'id':'S1-T02-AC01','status':'NOT_RUN','required_reviewer':'A04','reason':'Producer cannot independently accept own artifact'}
    })
    dump('docs/architecture/evidence/input-manifest.json', {'inputs': inputs, 'captured_utc':datetime.now(timezone.utc).isoformat(), 'status':'PASS',
        'meaning':'Downloaded byte hashes match supplied bindings; not independent acceptance of inputs'})
    observed = None
    observed_timestamp = ''
    for f in pathlib.Path(os.environ['CODEX_HOME'],'sessions').rglob('*.jsonl'):
        for line in f.read_text(encoding='utf-8').splitlines():
            try: row=json.loads(line)
            except ValueError: continue
            if row.get('type')=='turn_context' and pathlib.Path(row['payload'].get('cwd','')).resolve()==ROOT:
                p=row['payload']
                if row.get('timestamp','') < observed_timestamp:
                    continue
                observed_timestamp = row.get('timestamp','')
                observed={'turn_id':p.get('turn_id'),'model':p.get('model'),'effort':p.get('effort'),
                          'source_kind':'Codex session turn_context','source_file':f.name,
                          'source_line_sha256':hashlib.sha256(line.encode('utf-8')).hexdigest()}
    if observed is None or observed['model']!='gpt-6-astra' or observed['effort']!='high':
        raise ValueError('C_ARCH_RUNTIME_MISMATCH')
    versions={}
    for exe in ('multica','codex','git'):
        cmd=[shutil.which(exe), '--version']
        r=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
        versions[exe]={'command':f'{exe} --version','exit_code':r.returncode,'stdout':r.stdout.strip(),'stderr':r.stderr.strip()}
    git=subprocess.run(['git','rev-parse','--is-inside-work-tree'],cwd=ROOT,capture_output=True,text=True)
    dump('docs/architecture/evidence/runtime.json', {
       'producer_agent_uuid':AUTHOR,'producer_run_id':RUN,
       'requested_profile':{'id':'C_ARCH','model':'gpt-6-astra','effort':'high'},'observed_turn':observed,
       'runtime_note':'Latest matching session turn_context observed; no model substitution or runtime configuration changes.',
       'python':platform.python_version(),'platform':platform.platform(),'tools':versions,
       'git_probe':{'command':'git rev-parse --is-inside-work-tree','exit_code':git.returncode,'stdout':git.stdout.strip(),'stderr':git.stderr.strip()},
       'powershell_observed_version':'5.1.26100.6899',
       'editor':'NOT_RUN','gpu':'NOT_RUN','android':'NOT_RUN','packages_installed':False,
       'jsonschema_validator':'NOT_RUN: jsonschema package absent; no installation authorized',
       'previous_rework_run_id':'01a1b3e5-7dff-7360-8a5d-45353b68b1bc',
       'previous_run_end':'v1.0.1 independently rejected in SHIP-16; original FAIL preserved in rework2/input.',
       'run_started_utc':'2026-11-07T03:10:49Z',
       'captured_utc':datetime.now(timezone.utc).isoformat()
    })
    dump('docs/architecture/candidate.json', {
       'task_id':'S1-T02','issue_id':'01a1b3fc-c10b-70ba-82b8-dd886963a843','candidate_ref':CANDIDATE,
       'artifact_version':'1.0.2','interface_version':INTERFACE,'product_spec_version':'v1.2.0',
       'producer_agent_uuid':AUTHOR,'producer_run_id':RUN,'candidate_commit':'NOT_APPLICABLE_NO_GIT',
       'contract_sha256':EXPECTED['t02-contract-v1.json'],
       'spec_sha256':'22d5eb65bfaafd00de9b337f24078c9bdf104807bdc2c2c6135c1b718de87ea7',
       'test_version':'S1-T02-AC01@task_acceptance.json:910ff7c765586a5696da7275d2165ad7ca703d1707b852d96e38b86a24cafe22',
       'acceptance_status':'NOT_RUN','reviewer_agent_uuid':'4702408e-ea84-463c-8697-4f083ab903ed',
       'reviewer_run_id':None, 'author_of_all_authored_files':AUTHOR,
       'read_only_input_roots':['docs/architecture/inputs/','docs/architecture/rework-inputs/','docs/architecture/rework2/input/'],
       'allowed_paths':['docs/architecture/','specs/interfaces/','prototypes/architecture/'],
       'business_repair_attempt':2,'budget':{'max_run_minutes':120,'max_cost_cny':None,'max_repair_attempts':2},
       't03_released':False,'independent_review_required':True,
       'historical_fail':'SHIP-8 v1.1, SHIP-14 v1.0.0 and SHIP-16 v1.0.1 remain FAIL; no old acceptance is transferred',
       'supersedes_rejected_candidate':{
           'candidate_ref':'S1-T02-CANDIDATE-v1.0.1-20261107',
           'archive_sha256':'c2aeedd58af2bdae22f43f401ec2a1173e04f61e10a7c277ee633891177ffb1e',
           'verdict':'FAIL','review_record':'rework2/input/t02-acc-a04-review-record.json'},
       'developer_test_version':'S1-T02-DEV/1.0.2; original 38 methods retained plus tests 39-48',
       'input_refs':'evidence/input-manifest.json','developer_checks':'evidence/developer-validation.json'
    })
    dump('specs/interfaces/examples/move-command.json',{
      'record_type':'NavigationCommand','interface_version':INTERFACE,
      'session_epoch':'synthetic-session-1','ship_id':'synthetic-player','command_id':1,
      'type':'MoveTo','target_xz_m':{'x_m':100,'z_m':-50}
    })
    print('Prepared candidate, 9 verified source attachments, 26 requirement mappings; no acceptance decision.')


if __name__=='__main__':
    main()
