"""Producer-only byte preservation and before/after probes; not A04 acceptance.

Reads the rejected archive without extracting or modifying it. --record writes
the audit and source diff in the authorized evidence directory.
"""
import argparse
import ast
import difflib
import hashlib
import json
import math
import sys
import types
import zipfile
from datetime import datetime, timezone
from prepare_candidate import ROOT, AUTHOR, RUN, CANDIDATE, INTERFACE, load, dump
from protocol_model import ProtocolModel, shortest_heading_delta


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tests(source):
    return {n.name: ast.dump(n, include_attributes=False)
            for n in ast.walk(ast.parse(source))
            if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--record',action='store_true')
    args=parser.parse_args()
    inputs=ROOT/'docs/architecture/rework-inputs'
    archive=inputs/'S1-T02-architecture-v1.0.0.zip'
    archive_sha=sha(archive.read_bytes())
    assert archive_sha=='1df6a151698fd9a7c05889385781281d90c6cd3ffcb81d1f61a12793f644717d'
    review=load(inputs/'t02-acc-a04-review-record.json')
    probe=load(inputs/'a04-probe-report.json')
    assert review['verdict']=='FAIL' and review['artifact_sha256']==archive_sha
    assert probe['zip_sha256']==archive_sha
    assert {x['id'] for x in review['minimal_fixes']}=={'heading-shortest-arc','already-active-map-profile'}
    with zipfile.ZipFile(archive) as z:
        manifest=z.read('docs/architecture/SHA256SUMS.txt')
        assert sha(manifest)=='5d8b8729994111788eebb638620e885974b66b43426f9d09484ae84f0ee0df59'
        entries=dict((n,h) for h,n in (line.split('  ',1) for line in manifest.decode().splitlines()))
        assert len(entries)==54 and len(z.namelist())==55
        assert set(z.namelist())==set(entries)|{'docs/architecture/SHA256SUMS.txt'}
        assert all(sha(z.read(n))==h for n,h in entries.items())
        unchanged_inputs=[n for n in entries if n.startswith('docs/architecture/inputs/')]
        assert all((ROOT/n).read_bytes()==z.read(n) for n in unchanged_inputs)
        old_tests=tests(z.read('prototypes/architecture/verify.py').decode())
        new_tests=tests((ROOT/'prototypes/architecture/verify.py').read_text(encoding='utf-8'))
        assert len(old_tests)==33 and len(new_tests)==38
        assert all(new_tests[n]==body for n,body in old_tests.items())
        old_code=z.read('prototypes/architecture/protocol_model.py').decode()
        old=types.ModuleType('t02_rejected_model')
        sys.modules[old.__name__]=old
        exec(compile(old_code,'rejected_zip/protocol_model.py','exec'),old.__dict__)
        assert '((to-from+180)%360)-180' in z.read('docs/architecture/ADR-001-foundation.md').decode()
        angle_cases=[]
        for start,end,expected in ((0,180,180),(350,10,20)):
            euclidean=(end-start+180)%360-180
            truncating=math.fmod(end-start+180,360)-180
            actual=shortest_heading_delta(start,end)
            assert actual==expected
            angle_cases.append({'from':start,'to':end,'old_euclidean_result':euclidean,
                                'old_csharp_remainder_emulated':truncating,
                                'new_python_result':actual,'expected':expected})
        version_cases=[]
        for field in ('map_sha','profile_sha'):
            outcomes={}
            for label,cls in (('old',old.ProtocolModel),('new',ProtocolModel)):
                m=cls(radius=8)
                assert m.resolve(m.request(1,(100.,0.)))
                m.observe_tick((1.,0.),5.)
                setattr(m,field,'changed-'+field)
                result=m.request(2,(101.,0.))
                outcomes[label]={'result':'ALREADY_ACTIVE' if isinstance(result,str) else 'PLAN_REQUEST',
                                 'generation':m.generation,'active_target':m.target,
                                 'map_sha':m.map_sha,'profile_sha':m.profile_sha}
                if label=='old':
                    assert result=='ALREADY_ACTIVE' and m.generation==1
                else:
                    assert not isinstance(result,str) and m.generation==2
                    assert m.resolve(result)
                    assert m.target==(101.,0.)
                    assert (m.active_map_sha,m.active_profile_sha)==(m.map_sha,m.profile_sha)
                    outcomes[label]['resolved_target']=m.target
            version_cases.append({'changed_field':field,**outcomes})
        changed=[]
        diffs=[]
        for name in sorted(entries):
            current=(ROOT/name).read_bytes()
            previous=z.read(name)
            if current!=previous:
                changed.append({'path':name,'old_sha256':sha(previous),'new_sha256':sha(current)})
                if name.endswith(('.md','.py','.json')) and '/evidence/' not in name and name!='docs/architecture/traceability.json':
                    diffs.extend(difflib.unified_diff(previous.decode().splitlines(True),
                        current.decode().splitlines(True),fromfile='v1.0.0/'+name,tofile='v1.0.1/'+name))
    candidate=load(ROOT/'docs/architecture/candidate.json')
    contract=load(ROOT/'specs/interfaces/contract.json')
    schema=load(ROOT/'specs/interfaces/data.schema.json')
    command=load(ROOT/'specs/interfaces/examples/move-command.json')
    assert candidate['producer_run_id']==RUN and candidate['candidate_ref']==CANDIDATE
    assert candidate['business_repair_attempt']==1 and candidate['acceptance_status']=='NOT_RUN'
    assert contract['interface_version']==candidate['interface_version']==command['interface_version']==INTERFACE
    assert schema['$id']=='urn:s1:interfaces:1.0.1'
    assert not contract['windows_amendment']['effective'] and not candidate['t03_released']
    assert sha(archive.read_bytes())==archive_sha
    report={
        'candidate_ref':CANDIDATE,'producer_agent_uuid':AUTHOR,'producer_run_id':RUN,
        'record_kind':'PRODUCER_DEVELOPMENT_CHECKS_NOT_INDEPENDENT_ACCEPTANCE',
        'command':'python -B prototypes/architecture/audit_rework.py --record',
        'executed_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS',
        'rejected_archive_sha256':archive_sha,'rejected_manifest_entries_verified':len(entries),
        'immutable_input_files_byte_equal':len(unchanged_inputs),
        'original_test_methods_ast_unchanged':sorted(old_tests),
        'added_tests':sorted(set(new_tests)-set(old_tests)),
        'heading_probe':angle_cases,'version_binding_probe':version_cases,
        'rework_inputs':[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p.read_bytes())}
                         for p in sorted(inputs.iterdir()) if p.is_file()],
        'changed_original_members':changed,
        'source_sha256':sha((ROOT/'prototypes/architecture/audit_rework.py').read_bytes()),
        'interface_sha256':sha((ROOT/'specs/interfaces/contract.json').read_bytes()),
        'before_fix_validation':{'exit_code':1,'status':'FAIL','tests_run':38,
            'failures':2,'errors':1,'reason':'Old model ignores both versions; shortest_heading_delta not yet present',
            'log_sha256':sha((ROOT/'docs/architecture/evidence/rework-before-fix.log').read_bytes()),
            'protocol_model_sha256':sha(old_code.encode()),
            'note':'Old candidate metadata and original prepare_candidate were still in place for this baseline run'},
        'independent_acceptance':'NOT_RUN','csharp_compilation':'NOT_RUN','t03_released':False
    }
    if args.record:
        dump('docs/architecture/evidence/rework-audit.json',report)
        (ROOT/'docs/architecture/evidence/rework-source.diff').write_text(''.join(diffs),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('status','rejected_manifest_entries_verified',
        'immutable_input_files_byte_equal','added_tests','heading_probe','version_binding_probe')},indent=2))


if __name__=='__main__':
    main()
