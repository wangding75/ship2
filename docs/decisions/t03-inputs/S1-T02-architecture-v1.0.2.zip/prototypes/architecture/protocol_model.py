"""T02 executable protocol experiment, NOT a planner or production movement engine.

Pose/speed are controlled test inputs. No Unity, filesystem, network, Gate or leases.
The rectangle geometry helper is a synthetic disc sweep counterexample only.
"""
from dataclasses import dataclass, field
from math import hypot, isfinite

STATES = ('Idle', 'Moving', 'Stopping', 'Arrived', 'Blocked')
GEOMETRIC_REASONS = ('OUT_OF_BOUNDS', 'TARGET_ON_LAND',
                     'CLEARANCE_INSUFFICIENT', 'NO_PATH_FOUND')


def shortest_heading_delta(from_deg, to_deg):
    """Signed shortest turn in (-180, 180]; exact half-turn is positive.

    Python's % with positive divisor is Euclidean modulo. C# needs the
    negative-remainder adjustment documented in ADR-001 before this branch.
    Normalize inputs first to avoid overflow in subtraction of finite angles.
    """
    if not isfinite(from_deg) or not isfinite(to_deg):
        raise ValueError('INVALID_NUMBER')
    delta = ((to_deg % 360) - (from_deg % 360)) % 360
    return delta - 360 if delta > 180 else delta


@dataclass(frozen=True)
class Token:
    epoch: int
    generation: int
    command_id: int
    target: tuple
    map_sha: str
    profile_sha: str


@dataclass
class ProtocolModel:
    radius: float = 8.0
    position: tuple = (0.0, 0.0)
    heading: float = 0.0
    speed: float = 0.0
    state: str = 'Idle'
    epoch: int = 1
    generation: int = 0
    map_sha: str = 'synthetic-map'
    profile_sha: str = 'synthetic-profile'
    pending: Token | None = None
    target: tuple | None = None
    goal_id: int | None = None
    active_map_sha: str | None = None
    active_profile_sha: str | None = None
    arrival_ticks: int = 0
    pending_terminal: str = 'Idle'
    reason: str | None = None
    events: list = field(default_factory=list)
    receipts: dict = field(default_factory=dict)

    def emit(self, kind, **data):
        self.events.append({'epoch': self.epoch, 'sequence': len(self.events),
                            'kind': kind, **data})

    def _transition(self, state):
        assert state in STATES
        old = self.state
        self.state = state
        if old != state:
            self.emit('StateChanged', old=old, new=state)

    def _invalidate(self):
        self.generation += 1
        self.pending = None

    def request(self, command_id, target):
        if command_id in self.receipts:
            return self.receipts[command_id]
        if command_id <= max(self.receipts, default=0):
            raise ValueError('COMMAND_ORDER')
        if len(target) != 2 or not all(isfinite(v) for v in target):
            raise ValueError('INVALID_NUMBER')
        if (self.state == 'Moving' and self.target is not None and
                self.active_map_sha == self.map_sha and
                self.active_profile_sha == self.profile_sha and hypot(
                    target[0]-self.target[0], target[1]-self.target[1]) <= .25*self.radius):
            self.receipts[command_id] = 'ALREADY_ACTIVE'
            return 'ALREADY_ACTIVE'
        if (self.pending and self.pending.target == target and
                self.pending.map_sha == self.map_sha and
                self.pending.profile_sha == self.profile_sha):
            self.receipts[command_id] = self.pending
            return self.pending
        self._invalidate()
        token = Token(self.epoch, self.generation, command_id, target,
                      self.map_sha, self.profile_sha)
        self.pending = token
        self.receipts[command_id] = token
        return token

    def resolve(self, token, reason=None, *, connector_safe=True):
        if (token != self.pending or token.epoch != self.epoch or
                token.generation != self.generation or token.map_sha != self.map_sha or
                token.profile_sha != self.profile_sha):
            self.emit('StalePlanDiscarded')
            return False
        if not connector_safe and reason is None:
            self.emit('ReplanRequired')
            return False  # production planner must re-request from current pose
        self.pending = None
        if reason:
            assert reason in GEOMETRIC_REASONS
            self.reason = reason
            self.target = None
            self.goal_id = None
            self.active_map_sha = self.active_profile_sha = None
            self.arrival_ticks = 0
            self.pending_terminal = 'Blocked'
            self.emit('CommandRejected', reason=reason)
            self._transition('Stopping' if self.speed > .05 else 'Blocked')
            if self.state == 'Blocked':
                self.speed = 0
            return True
        self.reason = None
        self.pending_terminal = 'Idle'
        previous = self.state
        self.target = token.target
        self.goal_id = token.command_id
        self.active_map_sha = token.map_sha
        self.active_profile_sha = token.profile_sha
        self.arrival_ticks = 0
        self.emit('CommandAccepted', command_id=token.command_id)
        near = hypot(self.position[0]-self.target[0],
                     self.position[1]-self.target[1]) <= .5*self.radius
        if previous in ('Idle', 'Arrived', 'Blocked') and near and self.speed <= .20:
            self._transition('Arrived')
            self.speed = 0
            if previous != 'Arrived':
                self.emit('Arrived', goal_id=self.goal_id)
        else:
            self._transition('Moving')
        return True

    def stop(self, command_id):
        if command_id in self.receipts:
            return self.receipts[command_id]
        if command_id <= max(self.receipts, default=0):
            raise ValueError('COMMAND_ORDER')
        self.receipts[command_id] = 'STOP'
        self._invalidate()
        self.target = None
        self.goal_id = None
        self.active_map_sha = self.active_profile_sha = None
        self.arrival_ticks = 0
        self.pending_terminal = 'Idle'
        self.reason = None
        self.emit('StopRequested')
        self._transition('Stopping' if self.speed > .05 else 'Idle')
        if self.state == 'Idle':
            self.speed = 0
        return 'STOP'

    def observe_tick(self, position, speed):
        """Inject a synthetic already-integrated tick; does NOT simulate motion."""
        if not all(isfinite(v) for v in (*position, speed)) or speed < 0:
            raise ValueError('INVALID_NUMBER')
        self.position, self.speed = position, speed
        if self.state == 'Stopping' and speed <= .05:
            self.speed = 0
            self._transition(self.pending_terminal)
            self.emit('Stopped')
        elif self.state == 'Moving' and self.target is not None:
            inside = hypot(position[0]-self.target[0], position[1]-self.target[1]) <= .5*self.radius
            self.arrival_ticks = self.arrival_ticks+1 if inside and speed <= .2 else 0
            if self.arrival_ticks == 5:
                self.speed = 0
                self._transition('Arrived')
                self.emit('Arrived', goal_id=self.goal_id)

    def restore(self, saved, anchor, *, legal=True, world_matches=True):
        if not world_matches or not legal:
            raise ValueError('RESTORE_REJECTED')
        position, heading, previous = saved
        if previous not in STATES or not all(isfinite(v) for v in (*position, heading)):
            raise ValueError('RESTORE_REJECTED')
        self._invalidate()
        self.epoch += 1
        self.receipts.clear()
        self.position, self.heading, self.speed = position, heading % 360, 0
        self.target = self.goal_id = self.reason = None
        self.active_map_sha = self.active_profile_sha = None
        self.arrival_ticks = 0
        self.pending_terminal = 'Idle'
        at_port = hypot(position[0]-anchor[0], position[1]-anchor[1]) <= .5*self.radius
        self.state = ('Arrived' if previous in ('Idle', 'Arrived', 'Blocked') and at_port else 'Idle')
        self.emit('Ready')  # restore never manufactures an arrival event


def point_segment_distance(p, a, b):
    dx, dz = b[0]-a[0], b[1]-a[1]
    denom = dx*dx + dz*dz
    t = 0 if denom == 0 else max(0, min(1, ((p[0]-a[0])*dx+(p[1]-a[1])*dz)/denom))
    return hypot(p[0]-a[0]-t*dx, p[1]-a[1]-t*dz)


def rectangle_sweep_clearance(a, b, radius, rect):
    """Exact segment-to-axis-aligned rectangle distance minus disc radius.

    Only a synthetic experiment; not a polygon/hull/rotation production solver.
    """
    xmin, zmin, xmax, zmax = rect
    lo, hi = 0.0, 1.0
    intersects = True
    for origin, delta, lower, upper in ((a[0], b[0]-a[0], xmin, xmax),
                                        (a[1], b[1]-a[1], zmin, zmax)):
        if delta == 0:
            if not lower <= origin <= upper:
                intersects = False
        else:
            t0, t1 = sorted(((lower-origin)/delta, (upper-origin)/delta))
            lo, hi = max(lo, t0), min(hi, t1)
    if intersects and lo <= hi:
        return -radius
    corners = ((xmin,zmin), (xmin,zmax), (xmax,zmin), (xmax,zmax))
    endpoint_distance = lambda p: hypot(max(xmin-p[0],0,p[0]-xmax), max(zmin-p[1],0,p[1]-zmax))
    return min(endpoint_distance(a), endpoint_distance(b),
               *(point_segment_distance(p,a,b) for p in corners))-radius


def inside_world(p, radius):
    return all(-1024+radius <= v <= 1024-radius for v in p)
