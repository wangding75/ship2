"""Developer checks only. Run from any cwd; --record stores new producer evidence.

No third-party dependencies; schema checks here validate reference integrity, NOT
full Draft 2020-12 conformance. No Unity scene, planner, GPU or platform Gate runs.
"""
import argparse
import copy
import hashlib
import io
import json
import pathlib
import sys
import unittest
import zipfile
from datetime import datetime, timezone
from protocol_model import ProtocolModel, GEOMETRIC_REASONS, rectangle_sweep_clearance, inside_world
from prepare_candidate import ROOT, INPUT, EXPECTED, AUTHOR, RUN, CANDIDATE, load, dump


class InputAndContractChecks(unittest.TestCase):
    def test_01_nine_input_hashes(self):
        for name, expected in EXPECTED.items():
            with self.subTest(name=name):
                self.assertEqual(hashlib.sha256((INPUT/name).read_bytes()).hexdigest(), expected)

    def test_02_dependency_signature_binding(self):
        contract=load(INPUT/'t02-contract-v1.json')
        review=load(INPUT/'t01-rework1-acc-a02-review-record.json')
        dep=contract['dependency_acceptance_ref']
        self.assertEqual(review['verdict'],'PASS')
        self.assertEqual(review['artifact_sha256'],dep['candidate_sha256'])
        for key in ('producer_agent_uuid','producer_run_id','reviewer_agent_uuid','reviewer_run_id'):
            self.assertEqual(review[key],dep[key])
        self.assertNotEqual(review['producer_agent_uuid'],review['reviewer_agent_uuid'])
        self.assertNotEqual(review['producer_run_id'],review['reviewer_run_id'])
        self.assertIn({'id':'S1-T01-AC01','status':'PASS'},[{'id':x['id'],'status':x['status']} for x in review['checks']])

    def test_03_g14_exact_contract_signature(self):
        review=load(INPUT/'t02-contract-acc-a02-review-record.json')
        self.assertEqual(review['artifact_sha256'],EXPECTED['t02-contract-v1.json'])
        self.assertEqual(review['verdict'],'PASS')
        self.assertNotEqual(review['producer_agent_uuid'],review['reviewer_agent_uuid'])
        self.assertNotEqual(review['producer_run_id'],review['reviewer_run_id'])
        self.assertEqual(next(c['status'] for c in review['checks'] if c['id']=='G14'),'PASS')
        self.assertEqual(next(c['status'] for c in review['checks'] if c['id']=='S1-T02-AC01'),'NOT_RUN')

    def test_04_product_internal_manifest(self):
        with zipfile.ZipFile(INPUT/'S1-T01-product-specs-v1.2.zip') as z:
            lines=z.read('SHA256SUMS.txt').decode('utf-8-sig').splitlines()
            self.assertEqual(len(lines),6)
            for line in lines:
                sha,name=line.split(None,1)
                self.assertEqual(hashlib.sha256(z.read(name.strip())).hexdigest(),sha)

    def test_05_frozen_task_and_test_hashes(self):
        expected={'S1_tasks.json':'22d5eb65bfaafd00de9b337f24078c9bdf104807bdc2c2c6135c1b718de87ea7',
                  'task_acceptance.json':'910ff7c765586a5696da7275d2165ad7ca703d1707b852d96e38b86a24cafe22',
                  'acceptance_gate_policy.json':'fd2305a093b83bbc9ca47f1a911ec4eef4931caf901a6b4457388052056f9b15'}
        with zipfile.ZipFile(INPUT/'t00-specs-verified.zip') as z:
            for name,sha in expected.items():
                self.assertEqual(hashlib.sha256(z.read('specs/'+name)).hexdigest(),sha)

    def test_06_all_26_requirements_preserved(self):
        original=load(INPUT/'S1-T01-product-specs-v1.2/docs/product/S1_acceptance_traceability_matrix.json')
        trace=load(ROOT/'docs/architecture/traceability.json')
        self.assertEqual([e['source_requirement'] for e in trace['entries']], original['requirements'])
        self.assertEqual([r['req_id'] for r in original['requirements']], [f'REQ-S1-{i:03d}' for i in range(1,27)])
        for e in trace['entries']:
            self.assertEqual(e['this_candidate_runtime_verdict'],'NOT_RUN')
            for p in e['architecture_refs']:
                self.assertTrue((ROOT/'docs/architecture'/p).is_file(),p)

    def test_07_frozen_parameters_not_weakened(self):
        original=load(INPUT/'S1-T01-product-specs-v1.2/docs/product/S1_acceptance_traceability_matrix.json')
        contract=load(ROOT/'specs/interfaces/contract.json')
        self.assertEqual(contract['frozen_parameters_verbatim'],original['frozen_parameters'])
        self.assertEqual(contract['architecture_decisions']['fixed_dt_s'],.02)
        self.assertEqual(contract['architecture_decisions']['state_values'],['Idle','Moving','Stopping','Arrived','Blocked'])

    def test_08_route_quotas_100_and_negative_20_separate(self):
        frozen=load(ROOT/'specs/interfaces/contract.json')['frozen_parameters_verbatim']
        routes=frozen['routes_100_sample_spec']
        self.assertEqual([c['quota'] for c in routes['categories']],[15,15,20,15,20,15])
        self.assertEqual(sum(c['quota'] for c in routes['categories']),100)
        self.assertEqual([c['min_quota'] for c in routes['unreachable_negative_spec']['categories']],[6,5,4,5])
        self.assertTrue(routes['unreachable_negative_spec']['counted_separately_from_valid_routes'])
        self.assertEqual((routes['categories'][-1]['outbound_count'],routes['categories'][-1]['return_to_anchor_count']),(7,8))

    def test_09_windows_hold_and_figure_unknowns(self):
        c=load(ROOT/'specs/interfaces/contract.json')
        w=c['windows_amendment']
        self.assertFalse(w['effective'])
        for key in ('memory_counter','memory_threshold','memory_growth_rule','quality_settings','aspect_20_9_decision'):
            self.assertIsNone(w[key])
        self.assertEqual(w['p95_max_ms'],33.3)
        self.assertTrue(all(v is None for v in c['figure04_unknowns'].values()))
        self.assertFalse(c['t03_released'])

    def test_10_schema_local_references_resolve(self):
        schema=load(ROOT/'specs/interfaces/data.schema.json')
        self.assertEqual(schema['$schema'],'https://json-schema.org/draft/2020-12/schema')
        def walk(x):
            if isinstance(x,dict):
                if '$ref' in x:
                    path=x['$ref'].split('/')
                    self.assertEqual(path[0],'#')
                    node=schema
                    for p in path[1:]:node=node[p]
                for v in x.values():walk(v)
            elif isinstance(x,list):
                for v in x:walk(v)
        walk(schema)
        # Explicitly NOT a complete JSON Schema validator.

    def test_11_author_and_runtime_binding(self):
        c=load(ROOT/'docs/architecture/candidate.json')
        runtime=load(ROOT/'docs/architecture/evidence/runtime.json')
        self.assertEqual(c['producer_agent_uuid'],AUTHOR)
        self.assertEqual(c['producer_run_id'],RUN)
        self.assertEqual(runtime['observed_turn']['model'],'gpt-6-astra')
        self.assertEqual(runtime['observed_turn']['effort'],'high')
        self.assertEqual(c['acceptance_status'],'NOT_RUN')
        self.assertIsNone(c['reviewer_run_id'])
        self.assertNotEqual(c['producer_agent_uuid'],c['reviewer_agent_uuid'])


class ProtocolChecks(unittest.TestCase):
    def moving(self):
        m=ProtocolModel()
        m.resolve(m.request(1,(100.,0.)))
        m.observe_tick((1.,0.),5.)
        return m

    def test_12_stop_invalidates_inflight_result(self):
        m=self.moving(); t=m.request(2,(200.,0.))
        before=m.position
        m.stop(3)
        self.assertFalse(m.resolve(t))
        self.assertEqual(m.state,'Stopping')
        self.assertEqual(m.position,before)
        self.assertEqual(m.speed,5.)
        m.observe_tick((2.,0.),.05)
        self.assertEqual((m.state,m.speed),('Idle',0))

    def test_13_newer_target_wins_out_of_order_results(self):
        m=self.moving(); old=m.request(2,(200.,0.)); new=m.request(3,(300.,0.))
        self.assertFalse(m.resolve(old))
        self.assertTrue(m.resolve(new))
        self.assertEqual(m.target,(300.,0.))
        self.assertEqual((m.position,m.speed),((1.,0.),5.))

    def test_14_illegal_target_stops_before_blocked(self):
        for reason in GEOMETRIC_REASONS:
            with self.subTest(reason=reason):
                m=self.moving(); before=m.position
                m.resolve(m.request(2,(999.,999.)),reason)
                self.assertEqual((m.state,m.speed,m.position),('Stopping',5.,before))
                self.assertIsNone(m.target)
                self.assertEqual(m.reason,reason)
                self.assertEqual(m.events[-2]['kind'],'CommandRejected')
                m.observe_tick((2.,0.),.05)
                self.assertEqual((m.state,m.speed),('Blocked',0))

    def test_15_static_illegal_target_has_exact_zero_displacement(self):
        for state in ('Idle','Arrived','Blocked'):
            for reason in GEOMETRIC_REASONS:
                m=ProtocolModel(position=(5.,7.),state=state)
                m.resolve(m.request(1,(0.,0.)),reason)
                self.assertEqual((m.position,m.state),((5.,7.),'Blocked'))

    def test_16_legal_retarget_during_stopping_preserves_pose_and_speed(self):
        m=self.moving();m.stop(2)
        m.resolve(m.request(3,(200.,0.)))
        self.assertEqual((m.state,m.position,m.speed),('Moving',(1.,0.),5.))
        self.assertEqual(m.pending_terminal,'Idle')

    def test_17_duplicate_transport_and_near_target_are_idempotent(self):
        m=self.moving(); before=copy.deepcopy(m)
        self.assertEqual(m.request(1,(100.,0.)),m.receipts[1])
        self.assertEqual(m.request(2,(101.,0.)),'ALREADY_ACTIVE')
        self.assertEqual((m.generation,m.goal_id,m.events,m.position,m.speed),
                         (before.generation,before.goal_id,before.events,before.position,before.speed))

    def test_18_arrival_requires_five_consecutive_ticks(self):
        m=self.moving()
        for _ in range(4):m.observe_tick((100.,0.),.1)
        self.assertEqual(m.state,'Moving')
        m.observe_tick((105.,0.),.1)
        self.assertEqual(m.arrival_ticks,0)
        for _ in range(4):m.observe_tick((100.,0.),.1)
        self.assertEqual(m.state,'Moving')
        m.observe_tick((100.,0.),0.)
        self.assertEqual(m.state,'Arrived')
        for _ in range(10):m.observe_tick((100.,0.),0.)
        self.assertEqual(sum(e['kind']=='Arrived' for e in m.events),1)

    def test_19_speed_threshold_also_resets_arrival(self):
        m=self.moving()
        for _ in range(4):m.observe_tick((100.,0.),.2)
        m.observe_tick((100.,0.),.200001)
        self.assertEqual(m.arrival_ticks,0)
        self.assertEqual(m.state,'Moving')

    def test_20_stationary_near_target_TR02_exception(self):
        m=ProtocolModel()
        m.resolve(m.request(1,(1.,0.)))
        self.assertEqual((m.state,m.position),('Arrived',(0.,0.)))
        m.resolve(m.request(2,(1.,0.)))
        self.assertEqual(sum(e['kind']=='Arrived' for e in m.events),1)

    def test_21_map_and_profile_stale_results_rejected(self):
        for field in ('map_sha','profile_sha'):
            m=ProtocolModel();t=m.request(1,(100.,0.))
            setattr(m,field,'new-content')
            self.assertFalse(m.resolve(t))
            self.assertEqual(m.state,'Idle')

    def test_22_unsafe_connector_not_accepted(self):
        m=self.moving(); t=m.request(2,(200.,0.))
        self.assertFalse(m.resolve(t,connector_safe=False))
        self.assertEqual((m.target,m.position,m.speed),((100.,0.),(1.,0.),5.))

    def test_23_stop_clears_pending_blocked_terminal(self):
        m=self.moving();m.resolve(m.request(2,(0.,0.)),'TARGET_ON_LAND')
        m.stop(3);m.observe_tick((2.,0.),.01)
        self.assertEqual(m.state,'Idle')
        self.assertIsNone(m.reason)

    def test_24_restore_epoch_discards_old_plan(self):
        m=self.moving(); t=m.request(2,(200.,0.))
        m.restore(((37.123,44.567),359.9,'Moving'),(0.,0.))
        self.assertEqual((m.state,m.speed,m.position,m.heading),('Idle',0,(37.123,44.567),359.9))
        self.assertFalse(m.resolve(t))
        self.assertEqual(sum(e['kind']=='Arrived' for e in m.events),0)

    def test_25_restore_all_five_states_at_anchor(self):
        for state in ('Idle','Moving','Stopping','Arrived','Blocked'):
            m=ProtocolModel();m.restore(((0.,0.),90.,state),(0.,0.))
            self.assertEqual(m.state,'Idle' if state in ('Moving','Stopping') else 'Arrived')
            self.assertFalse(any(e['kind']=='Arrived' for e in m.events))

    def test_26_invalid_restore_preserves_existing_session(self):
        for kwargs in ({'legal':False},{'world_matches':False}):
            m=self.moving(); before=copy.deepcopy(m)
            with self.assertRaisesRegex(ValueError,'RESTORE_REJECTED'):
                m.restore(((999.,999.),20.,'Moving'),(0.,0.),**kwargs)
            self.assertEqual(m,before)

    def test_27_twenty_logical_restores_are_stable(self):
        m=ProtocolModel(); saved=((15.12345,-35.6789),78.123,'Moving')
        for _ in range(20):
            m.restore(saved,(0.,0.))
            self.assertEqual((m.position,m.heading,m.speed,m.state),(saved[0],saved[1],0,'Idle'))
            self.assertEqual(m.receipts,{})
        self.assertEqual(sum(e['kind']=='Ready' for e in m.events),20)
        # Does not test Unity object/subscription lifetime.

    def test_28_nonfinite_target_rejected_before_mutation(self):
        m=ProtocolModel(); before=copy.deepcopy(m)
        for value in (float('nan'),float('inf'),float('-inf')):
            with self.assertRaisesRegex(ValueError,'INVALID_NUMBER'):m.request(1,(value,0.))
            self.assertEqual(m,before)

    def test_34_shortest_heading_signed_tie_and_wrap(self):
        from protocol_model import shortest_heading_delta
        cases = ((0,180,180), (350,10,20), (10,350,-20), (180,0,180),
                 (0,0,0), (0,179,179), (0,181,-179), (359,0,1),
                 (0,359,-1), (-10,10,20), (720,180,180))
        for start,end,expected in cases:
            with self.subTest(start=start,end=end):
                actual=shortest_heading_delta(start,end)
                self.assertEqual(actual,expected)
                self.assertTrue(-180 < actual <= 180)

    def assert_near_target_replans_after_version_change(self, field):
        m=self.moving()
        self.assertEqual((m.target,m.radius),((100.,0.),8.))
        old_generation=m.generation
        before=(m.position,m.speed)
        setattr(m,field,'changed-'+field)
        token=m.request(2,(101.,0.))
        self.assertNotEqual(token,'ALREADY_ACTIVE')
        self.assertEqual(m.generation,old_generation+1)
        self.assertEqual((token.map_sha,token.profile_sha),(m.map_sha,m.profile_sha))
        self.assertEqual((m.position,m.speed),before)
        self.assertTrue(m.resolve(token))
        self.assertEqual(m.target,(101.,0.))
        self.assertEqual((m.active_map_sha,m.active_profile_sha),(m.map_sha,m.profile_sha))
        self.assertEqual(m.request(3,(102.,0.)),'ALREADY_ACTIVE')

    def test_35_active_near_target_map_change_replans(self):
        self.assert_near_target_replans_after_version_change('map_sha')

    def test_36_active_near_target_profile_change_replans(self):
        self.assert_near_target_replans_after_version_change('profile_sha')

    def test_37_near_click_preserves_pending_far_target(self):
        m=self.moving(); far=m.request(2,(300.,0.))
        generation=m.generation
        self.assertEqual(m.request(3,(101.,0.)),'ALREADY_ACTIVE')
        self.assertEqual((m.pending,m.generation),(far,generation))
        self.assertTrue(m.resolve(far))
        self.assertEqual(m.target,(300.,0.))

    def test_38_near_target_tolerance_boundary_unchanged(self):
        m=self.moving()
        self.assertEqual(m.request(2,(102.,0.)),'ALREADY_ACTIVE')
        self.assertNotEqual(m.request(3,(102.000001,0.)),'ALREADY_ACTIVE')


    def assert_pending_versions_refresh(self, moving, fields):
        m=self.moving() if moving else ProtocolModel()
        target=(101.,0.) if moving else (100.,0.)
        command_id=2 if moving else 1
        if moving:
            for field in fields:setattr(m,field,field+'-B')
        old=m.request(command_id,target)
        before=(m.state,m.target,m.goal_id,m.position,m.speed,
                m.active_map_sha,m.active_profile_sha)
        obsolete=[]
        for version in ('C','D','E'):
            with self.subTest(version=version):
                for field in fields:setattr(m,field,field+'-'+version)
                command_id+=1
                new=m.request(command_id,target)
                self.assertIsNot(new,old)
                self.assertEqual(new.generation,old.generation+1)
                self.assertEqual(new.command_id,command_id)
                self.assertEqual((new.map_sha,new.profile_sha),(m.map_sha,m.profile_sha))
                self.assertIs(m.pending,new)
                obsolete.append(old)
                for stale in obsolete:self.assertFalse(m.resolve(stale))
                self.assertEqual((m.state,m.target,m.goal_id,m.position,m.speed,
                                  m.active_map_sha,m.active_profile_sha),before)
                self.assertIs(m.pending,new)
                command_id+=1
                self.assertIs(m.request(command_id,target),new)
                self.assertEqual(m.generation,new.generation)
                old=new
        self.assertTrue(m.resolve(new))
        self.assertEqual((m.state,m.target),('Moving',target))
        self.assertEqual((m.active_map_sha,m.active_profile_sha),(m.map_sha,m.profile_sha))
        self.assertIsNone(m.pending)
        for stale in obsolete:self.assertFalse(m.resolve(stale))
        self.assertEqual((m.target,m.goal_id),(target,new.command_id))

    def test_39_moving_same_pending_map_changes(self):
        self.assert_pending_versions_refresh(True,('map_sha',))

    def test_40_moving_same_pending_profile_changes(self):
        self.assert_pending_versions_refresh(True,('profile_sha',))

    def test_41_moving_same_pending_both_change(self):
        self.assert_pending_versions_refresh(True,('map_sha','profile_sha'))

    def test_42_idle_same_pending_map_changes(self):
        self.assert_pending_versions_refresh(False,('map_sha',))

    def test_43_idle_same_pending_profile_changes(self):
        self.assert_pending_versions_refresh(False,('profile_sha',))

    def test_44_idle_same_pending_both_change(self):
        self.assert_pending_versions_refresh(False,('map_sha','profile_sha'))

    def test_45_same_versions_coalesce_pending_in_idle_and_moving(self):
        for moving in (False,True):
            with self.subTest(moving=moving):
                m=self.moving() if moving else ProtocolModel()
                first=m.request(2,(300.,0.))
                generation=m.generation
                for command_id in (3,4,5):
                    self.assertIs(m.request(command_id,(300.,0.)),first)
                    self.assertEqual(m.generation,generation)
                self.assertTrue(m.resolve(first))
                self.assertEqual(m.target,(300.,0.))

    def test_46_content_sha_roundtrip_without_new_request_still_resolves(self):
        for fields in (('map_sha',),('profile_sha',),('map_sha','profile_sha')):
            with self.subTest(fields=fields):
                m=ProtocolModel(); token=m.request(1,(100.,0.))
                for field in fields:setattr(m,field,'temporary-'+field)
                self.assertFalse(m.resolve(token))
                for field in fields:setattr(m,field,getattr(token,field))
                self.assertTrue(m.resolve(token))

    def test_47_near_threshold_scales_with_radius_and_includes_boundary(self):
        for radius in (4.5,6.5,8.):
            with self.subTest(radius=radius):
                m=self.moving();m.radius=radius
                self.assertEqual(m.request(2,(100.+.25*radius,0.)),'ALREADY_ACTIVE')
                self.assertNotEqual(m.request(3,(100.+.25*radius+.000001,0.)),'ALREADY_ACTIVE')

    def test_48_transport_replay_does_not_reactivate_stale_token(self):
        m=ProtocolModel();old=m.request(1,(100.,0.))
        m.map_sha='map-B';new=m.request(2,(100.,0.))
        self.assertIsNot(new,old)
        self.assertIs(m.request(1,(100.,0.)),old)
        self.assertIs(m.pending,new)
        self.assertFalse(m.resolve(old))
        self.assertTrue(m.resolve(new))


class GeometryCounterexamples(unittest.TestCase):
    def test_29_endpoints_clear_but_sweep_hits_island(self):
        rect=(-1.,-1.,1.,1.)
        self.assertGreater(rectangle_sweep_clearance((-10.,0.),(-10.,0.),1.,rect),0)
        self.assertGreater(rectangle_sweep_clearance((10.,0.),(10.,0.),1.,rect),0)
        self.assertLess(rectangle_sweep_clearance((-10.,0.),(10.,0.),1.,rect),0)

    def test_30_ship_radius_matters_in_sweep(self):
        rect=(-1.,-1.,1.,1.)
        self.assertGreater(rectangle_sweep_clearance((-10.,3.),(10.,3.),1.,rect),0)
        self.assertLess(rectangle_sweep_clearance((-10.,3.),(10.,3.),2.1,rect),0)

    def test_31_legal_water_anchor_clearance_12m(self):
        rect=(-10.,-10.,10.,10.)
        def anchor_valid(p):
            return inside_world(p,12) and rectangle_sweep_clearance(p,p,12,rect)>=0
        self.assertTrue(anchor_valid((30.,0.)))
        self.assertFalse(anchor_valid((0.,0.)))
        self.assertFalse(anchor_valid((21.9,0.)))
        self.assertFalse(anchor_valid((1020.,0.)))

    def test_32_world_boundary_checks_entire_disc(self):
        self.assertFalse(inside_world((1020.,0.),8.))
        self.assertTrue(inside_world((1016.,0.),8.))
        self.assertTrue(inside_world((-1016.,-1016.),8.))

    def test_33_long_hull_requires_more_than_radius_disc(self):
        length,radius=32,8
        half_segment=max(0,length/2-radius)
        self.assertEqual(half_segment+radius,16)
        self.assertGreater(half_segment+radius,radius)
        self.assertFalse(inside_world((0.,1012.),half_segment+radius))
        self.assertTrue(inside_world((0.,1012.),radius))


class RecordResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.records=[]
    def addSuccess(self,test):
        super().addSuccess(test);self.records.append({'id':test.id(),'status':'PASS'})
    def addFailure(self,test,err):
        super().addFailure(test,err);self.records.append({'id':test.id(),'status':'FAIL','detail':self._exc_info_to_string(err,test)})
    def addError(self,test,err):
        super().addError(test,err);self.records.append({'id':test.id(),'status':'FAIL','detail':self._exc_info_to_string(err,test)})
    def addSubTest(self,test,subtest,err):
        super().addSubTest(test,subtest,err)
        if err:self.records.append({'id':subtest.id(),'status':'FAIL','detail':self._exc_info_to_string(err,test)})


def main():
    args=argparse.ArgumentParser();args.add_argument('--record',action='store_true');options=args.parse_args()
    stream=io.StringIO()
    suite=unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromTestCase(c) for c in
                             (InputAndContractChecks,ProtocolChecks,GeometryCounterexamples))
    result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=RecordResult).run(suite)
    log=stream.getvalue();print(log)
    if options.record:
        logpath=ROOT/'docs/architecture/evidence/developer-validation.log'
        logpath.write_text(log,encoding='utf-8')
        source_files=[ROOT/'prototypes/architecture'/n for n in ('protocol_model.py','verify.py','prepare_candidate.py','audit_rework2.py','package.py')]
        source_files += sorted((ROOT/'specs/interfaces').rglob('*.json'))
        dump('docs/architecture/evidence/developer-validation.json',{
            'candidate_ref':CANDIDATE,'record_kind':'PRODUCER_DEVELOPMENT_CHECKS_NOT_INDEPENDENT_ACCEPTANCE',
            'producer_agent_uuid':AUTHOR,'producer_run_id':RUN,
            'developer_test_version':'S1-T02-DEV/1.0.2',
            'acceptance_test_version':load(INPUT/'t02-contract-v1.json')['test_version'],
            'command':'python -B prototypes/architecture/verify.py --record',
            'executed_utc':datetime.now(timezone.utc).isoformat(), 'tests_run':result.testsRun,
            'exit_code':0 if result.wasSuccessful() else 1,
            'status':'PASS' if result.wasSuccessful() else 'FAIL','checks':result.records,
            'source_hashes':[{ 'path':p.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in source_files],
            'log_sha256':hashlib.sha256(logpath.read_bytes()).hexdigest(),
            'limits':[
                {'id':'JSON_SCHEMA_FULL_VALIDATION','status':'NOT_RUN','reason':'Third-party jsonschema absent; local references/JSON syntax checked only'},
                {'id':'S1-T02-AC01','status':'NOT_RUN','reason':'A04 separate UUID/Run required'},
                {'id':'UNITY_BUILD_SCENE_REENTRY','status':'NOT_RUN','reason':'T02 does not initialize or run Unity'},
                {'id':'100_ROUTES_AND_20_NEGATIVES_RUNTIME','status':'NOT_RUN','reason':'Only quotas/source equality checked; production map/fixtures not authored'},
                {'id':'POLYGON_CAPSULE_TURNING_AND_BRAKING_RUNTIME','status':'NOT_RUN','reason':'Synthetic rectangle/disc and protocol experiments only'},
                {'id':'G01_G14_GATE_AND_RESOURCE_LEASES','status':'NOT_RUN','reason':'Protocol design only; implementation belongs to T03'},
                {'id':'WINDOWS_PERFORMANCE_BASELINE','status':'BLOCKED','reason':'Owner memory/quality/20:9 parameters and G14 outstanding'},
                {'id':'GPU_ANDROID_VISUAL_INPUT_PERFORMANCE','status':'NOT_RUN','reason':'No device/Unity action authorized or executed'}
            ]})
    return 0 if result.wasSuccessful() else 1


if __name__=='__main__':sys.exit(main())
