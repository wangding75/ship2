# S1-INTERFACES/1.0.2 模块接口

以下是语言无关的C#风格签名说明，不声称可编译API已实现。DTO结构见data.schema.json；冻结数值/枚举见contract.json。方法失败返回带code的Result，不用null表示成功。所有快照只读，事件回调不能在调用栈内重入修改状态，命令排到下一逻辑tick。

| 提供者 / 消费者 | 签名与输出 | 约束 |
|---|---|---|
| WorldRepository / Nav、Camera、Session | `Load(WorldRef) -> Result<WorldNavigationData>` | 校验版本、SHA、有限坐标、几何和唯一合法anchor，失败不Ready |
| WorldGeometry / Planner、Motion | `ClassifyTarget(XZ,ShipProfile) -> TargetCheck`；`Sweep(Pose from,Pose to,ShipProfile) -> SweepResult` | TargetCheck带四类几何原因；Sweep检查整个转向扫掠及world边界；不能返回仅中心点判断 |
| PathPlanner / NavCore | `Request(PlanRequest,Cancellation) -> request_id`；`OnPlanResult(PlanResult)` | 异步；epoch/generation/map/profile必须原样返回；成功含路径、走廊、弧长与起点姿态 |
| NavCore / Input、StressDriver | `Submit(NavigationCommand) -> Receipt` | Receipt仅表示入队；最终Accepted/Rejected另发事件。Stop也能使pending失效 |
| NavCore / SimulationHost | `Tick(tick_index,dt_s=0.02)` | 仅host可调用，无UnityTime依赖，禁止变量dt |
| NavCore / HUD、Camera、Visual、Wake | `Read(ship_id) -> NavigationSnapshot`；`Subscribe(listener) -> DisposableHandle` | 同tick快照一致；read不可改变世界；dispose幂等 |
| Selection / Input、HUD | `Select(ship_id) -> Result`；`ClearSelection()` | 只能控制player角色，stress被拒；选中不新增实体 |
| InputRouter / Nav、Camera | `Consume(PointerSample) -> InputDisposition` | disposition为UI/Drag/Zoom/Selection/WorldClick/Ignore；一手势一个结果 |
| CameraRig / Input、Save | `Pan(delta_xz)`；`Zoom(delta)`；`ResetFollow(ship_id)`；`ReadCamera()` | 限界连续；重入从camera快照重建，不碰Nav |
| VisualAdapter / Nav快照 | `Apply(snapshot,render_alpha,wave_sample)` | NavRoot仅position/heading映射，VisualRoot只视觉；插值不反馈逻辑 |
| WakeRenderer / Nav快照 | `Sample(WakeSample)`；`StopEmission(ship_id)`；`DisposeSession(epoch)` | 世界坐标、固定池、旧epoch拒绝、LOD不清轨迹 |
| Session / 全部模块 | `Capture() -> MinimalSessionSnapshot`；`Restore(snapshot) -> Result<Ready>`；`ColdReset()`；`Dispose()` | validate-before-replace；SAFE_IDLE；停旧任务/解绑后再建，事务失败不假报Ready |
| AssetCatalog / Composition | `ResolveShip(profile_id) -> profile+prefab_ref` | profile内容sha与实际包络/Prefab绑定，引用缺失拒绝 |
| EvidenceSink / 独立记录器 | `Append(TickRecord or EventRecord)` | 按epoch/tick/ship/seq稳定排序；原始证据禁止事后只保留成功帧 |

## DTO字段和语义

`XZ={x_m,z_m}`；`Pose={position_xz_m,heading_deg}`；`ShipProfile={profile_id,profile_sha,length_m,nav_radius_m,capsule_half_segment_m,v_max_mps,a_acc_mps2,a_stop_mps2,omega_max_degps}`。生产读取时必须验证 `capsule_half_segment=max(0,length/2-R)` 与网格包络，示例不充当资产合格证明。

航向最短角差按ADR-001的欧氏模定义，范围(-180,180]、平角正向，0→180=+180、350→10=+20；C#截断余数须先归一化。NavCore在目标接受时私有保存 `active_map_sha/active_profile_sha`；近点 `ALREADY_ACTIVE` 必须同时匹配当前map和profile。绑定随目标清除、Stop或恢复清空；成功规划才更新。该内部绑定不改变外部DTO字段结构或既有0.25*R_nav阈值。

同目标 pending 合并也必须同时满足 `pending.map_sha == map_sha` 和 `pending.profile_sha == profile_sha`；任一不符则使旧 token 失效、generation 递增，并绑定当前哈希重新规划。此规则覆盖接受前 Idle 和 Moving 的连续版本变化，旧 resolve 不得覆盖新请求；版本一致时仍合并。相同 command_id 的传输重放及内容哈希变回原值的语义保持 ADR-002 所述规则。

`NavigationCommand={interface_version,session_epoch,ship_id,command_id,type,target_xz_m?}`；type为MoveTo/Stop/ReturnToPort，只有MoveTo必须提供target，其余禁止携带自定义target；Return从WorldRepository读取anchor，不能信任UI传来的港口建筑位置。外部输入非法number不送入几何内核。

`PlanRequest={epoch,ship_id,generation,command_id,map_sha,profile_sha,start_pose,start_speed_mps,start_tick,target,is_port_anchor}`。`PlanResult`镜像所有绑定字段并带 `outcome=Success|Rejected|Error`；Success包含 `points_xz_m,corridor_ref,total_length_m`，Rejected含四个几何原因之一，Error含系统错误。成功路径非空且终点必须仍为请求目标（在原到达容差内也不得暗中放大目标）；已接受goal保留原目标，不能拿最近可达点替换后报成功。

`NavigationSnapshot={epoch,ship_id,tick,revision,state,pose,speed_mps,angular_speed_degps,active_goal_id,active_target_xz_m,pending_target_xz_m,remaining_path_m,blocked_reason,pending_terminal,arrival_ticks,generation}`。active_goal/target/path可null但需一致；Idle/Blocked/Arrived速度为0且没有活动path；Stopping可以有制动走廊，pending_terminal仅Idle或Blocked。BlockedReason属于最近拒绝消息；Stopping时也能显示它。

事件统一外壳 `{interface_version,epoch,ship_id,tick,event_seq,command_id,goal_id,event_type,payload}`。event_seq在单epoch内单调递增，监听者按 `(epoch,event_seq)`去重。事件类型包括CommandAccepted、CommandRejected、CommandIgnored、StateChanged、StopRequested、Stopped、Arrived、StalePlanDiscarded、RestoreRejected、Ready、Disposed、SafetyViolation。每条具体事件必须带该类必要证据：Arrived带target/final/error_m/is_port_anchor，Rejected带原始目标/reason，StateChanged带from/to，SafetyViolation带from_pose/proposed_pose/map_sha/profile_sha。

## 证据与测试数据接口

TickRecord必须记录实际逻辑pose、speed/omega、state、goal、arrival_ticks、world/profile SHA、dt、扫掠最小净空/结果；采样每逻辑tick，不用渲染帧近似。Fixture记录seed、map_sha、profile_sha、fixture_sha、independent_verifier、起终点/分类/预期原因、时间限制。A11生成100条合法和≥20负例，A13使用独立几何实现复核；不调用被测Planner筛选样本。路线PASS需T01四条件同时成立：到达5ticks/一次事件，整个代理零穿岛，位移/转向≤上限*dt*1.05，包络零越界；时限 `L_path/v_max*2.5+15s`。返航配额7出港+8返航，负例不得进入合法路线分母。

测试源文件SHA亦进入候选清单；后续必须注入至少3类故障验证测试有效性，例如篡改导航位置、重复到达事件、UI点击穿透。此处约定接口，不创建A11生产夹具或声称运行验收通过。
