# T02候选变更记录

## 1.0.2 / 2026-11-07 / T02-REWORK-2（最后第2/2轮）

唯一逻辑修复：同目标pending只有在token.map_sha与token.profile_sha都匹配当前哈希时才合并；任一不符则沿既有invalidate路径递增generation、签发当前版本token。覆盖Moving和首次接受前Idle，不再连续返回旧token。ADR-002、module-api和contract.changed_version同步；candidate/interface/DEV版本升至1.0.2，DTO结构及snapshot_version=1.0.0不变。

原38项测试AST完整保留（含最初33项），增加39–48共10项：Moving/Idle × map/profile/二者变化、连续变化与稳定后重复请求、旧token拒绝与新token成功、同版本pending合并、内容哈希回转、三种半径0.25R边界、传输重放不复活旧token。新增测试在旧实现上实际运行失败，完整日志保留；修复后48项通过。不是Unity、C#或真实路线验收。

原任务契约、S1-T02-AC01、所有冻结参数、近点不取消pending远目标、角差(-180,180]及+180/+20、omega_max与1.05均不变。输入与历史v1.0.0/v1.0.1完整ZIP、SHIP-14/SHIP-16 FAIL均只读保留。Windows草案effective=false及T03门槛不变。

本轮作者A03，Run `01a1b3fc-c47f-7e87-b7af-d37e32a2ca27`。无Git提交；新候选独立验收NOT_RUN，交A04不同UUID/Run，结果回A00。不得开启第3轮。

## 1.0.1 / 2026-11-07 / T02-REWORK-1

修复独立验收指出的两项既有契约缺陷；任务契约T02-contract-v1、S1-T02-AC01、范围、阈值与依赖不变。

1. ADR-001统一角差到(-180,180]、平角+180，并明确Python欧氏模与C#截断余数的区别；增加纯逻辑shortest_heading_delta及0→180=+180、350→10=+20等断言。
2. ProtocolModel成功接受目标时绑定active_map_sha/active_profile_sha；ALREADY_ACTIVE要求两者都与当前版本一致。Stop、拒绝清目标、恢复时清空绑定。对活动目标(100,0)、R=8、新点(101,0)，分别改变map/profile后必须生成新规划；新结果成功接受后才重新允许近点幂等。

ADR-002、模块接口、机器契约同步。接口补丁升为S1-INTERFACES/1.0.1；内部目标版本绑定不增加外部DTO必填字段，snapshot_version仍为1.0.0。生成和打包脚本同步新candidate_ref、Run及版本；当前工具证据重新采集。原33项测试保留，增加5项回归，包含pending远目标交错及0.25*R边界。

omega_max、1.05、0.25*R_nav、26条需求、100合法路线及≥20负例、锚点、图4来源与未知项、Windows effective=false、历史Android条款均不变。未实施平台迁移、Unity、Gate或设备工作。完整旧候选及原始FAIL仍在rework-inputs/，原输入在inputs/，均逐字节保留。

上一Run `01a1b0bc-25c5-7824-92f9-8ec71e320c03`因用量上限结束；本轮制作Run为 `01a1b3e5-7dff-7360-8a5d-45353b68b1bc`。这是第1轮业务返工，总上限2轮，未借恢复重置计数。无Git仓库、无提交号；以真实ZIP和完整清单SHA交付。

## 1.0.0 / 2026-11-06

旧候选 `S1-T02-CANDIDATE-v1.0.0-20261106`，ZIP SHA256 `1df6a151698fd9a7c05889385781281d90c6cd3ffcb81d1f61a12793f644717d`。A04在SHIP-14给出FAIL；本补丁不覆写历史判定。新候选等待A00安排A04独立复验。
