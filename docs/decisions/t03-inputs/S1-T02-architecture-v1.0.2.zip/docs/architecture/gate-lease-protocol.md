# Gate 与资源租约协议设计 v1.0.0

实施者A14/T03，审查A04/A13。本候选只设计协议；没有Gate进程、平台集成或实际资源锁，所有相应运行检查NOT_RUN。冻结原文在inputs/t00-specs-verified.zip中，不修改G01..G14。

## Gate入口与不可伪造身份

抽象 `Evaluate(candidate_digest,contract_digest,review_record_refs,evidence_manifest_ref,requested_transition)` -> `GateDecision`。输入引用必须由受保护执行环境取回原字节及平台作者/Run元数据；从身份凭证上下文取得writer_uuid，不信任JSON里的reviewer字段。职责表来自已签核任务契约并与平台真实UUID绑定。所有路径规范化后必须在受检根内，拒绝路径穿越、symlink越界、缺失文件、同路径重复条目。

Decision：decision_id、candidate/spec/test/contract SHA、rule_results[{id,status,evidence_refs}]、allowed(bool)、blocking_reasons、policy_sha、created_utc、authenticated_writer、audit_digest。required规则出现FAIL/BLOCKED/NOT_RUN/缺失/空证据，allowed=false。非适用项不能随手写N/A略过：原规则适用性由已签核契约确定并附解释；本候选开发检查不产生ACCEPTED状态。

| 规则 | 必须校验的实质 | 预期负例 |
|---|---|---|
| G01 | 制作者与验收者UUID和Run均不同 | 同Agent不同Run拒绝 |
| G02 | 验收者不在任一受检源码/资产/测试作者或修改记录中 | 不同Agent修改后自签拒绝 |
| G03 | 实际candidate commit（无Git显式不适用）、artifact/spec/test/contract SHA一致 | 旧SHA PASS拒绝 |
| G04 | 所有required检查PASS且原始证据可读/绑定 | 缺证据、NOT_RUN、未知检查拒绝 |
| G05 | required任务具有真实签核，不以cancelled替代 | 取消required任务仍拒绝 |
| G06 | 受检前后源码/资产/测试逐文件SHA一致，缓存白名单隔离 | 验收中改代码拒绝 |
| G07 | 契约指定全部reviewer_roles均签核当前SHA | 缺A07/A13之一拒绝 |
| G08 | 合并后commit重新构建与相关回归 | 分支PASS搬运拒绝 |
| G09 | 真实GPU帧，原Android要求绑定真机/质量；Windows替代未生效 | 空渲染、模拟器、换机拒绝 |
| G10 | 验收记录由角色凭证/受保护CI提交，来源可认证 | 自报reviewer_uuid拒绝 |
| G11 | 最多2轮业务返工，独立记录infra retry/时间/费用 | 第3轮自动修复拒绝 |
| G12 | 租约绑定任务/进程/工作树/端口；确认旧进程停止才释放 | 同端口双租约拒绝 |
| G13 | A15读取全套证据并复跑关键案例 | A00/制作记录代签拒绝 |
| G14 | 实例契约经A02签核精确SHA；T00例外由A13 | 变更范围后沿用旧签名拒绝 |

测试至少覆盖冻结8种negative_probes，额外覆盖伪造身份、证据路径穿越、已签文件修改、相同lease key竞争。预期拒绝不以脚本非零退出本身计PASS，必须断言拒绝原因与记录。T03实现后回放bootstrap签核；T00-T02先行允许平台可追溯独立记录，不能要求不存在的Gate批准自身前置，也不能写自动Gate已PASS。

评审开始封存候选；评审只写隔离证据/获授权派生缓存，结束再hash；发现修改立即失效。签核后变更任何受检文件形成新候选，旧PASS不能复用。平台in_review表示交付待验，done由人决定；这些状态均不等于Gate业务ACCEPTED。

## 租约资源与状态

资源键 `unity_editor:<canonical_worktree>`，并额外独占 `(host,bridge_port)`；`gpu_capture:<host,physical_adapter_id>`；`android_device:<serial>`。获取多资源按类型及资源键字典序，防止死锁。Windows-only草案不执行android租约，正式策略必须等新G14；本T02不用任何资源。

`LeaseRequest`含task/agent/run_uuid、resource_keys、canonical_worktree、tool_version、host_id、requested_ports、TTL；凭证鉴权在服务端。原子AcquireAll(compare-and-set)返回lease_id、单调fencing_token、expires_utc；冲突返回RESOURCE_BUSY，不“抢锁”。本地实现必须对文件/数据库执行操作系统原子锁，而非“先查后写”的竞态。

状态 `RESERVED -> ACTIVE -> RELEASING -> RELEASED`；任何崩溃/超时到 `ORPHANED`，不能直接RELEASED。启动子进程后AttachProcess绑定PID、process_start_utc、executable_hash、owner_run、端口和worktree；PID必须结合启动时间验证，防止复用。心跳默认10s、TTL30s为协议建议值，T03可配置并绑定版本；每次操作验证token未过期且等于当前fence，过期工作者禁止继续写。

Release：阻止新工作 -> 停止本租约子进程 -> 验证PID与启动时间、端口释放、Editor锁释放 -> 写Released。无法证明停止则保留ORPHANED并BLOCKED，恢复者调查或人工处理后才能提升fence重新分配；TTL到期不是杀进程证据。禁止按进程名杀Unity/multica；任何Multica子进程终止前先以CLI核对daemon PID，不能误杀工作区daemon。

崩溃恢复读取持久日志，逐个核对host/进程指纹/端口/工作树；存活旧进程不可同时新启动，权限不足则阻塞。GPU同物理适配器互斥，不能把多个逻辑显示器当多个GPU槽位。资源在整个导入/构建/实测期间持有；证据写run绑定lease_id/token/设备/驱动/质量档，释放后仍保留审计。

## Editor自动化边界

T03按契约通过后执行：取得lease -> 预检版本/模块/许可/工作树 -> Package Manager解析并锁定 -> 导入并保存meta -> 编译 -> 运行必要EditMode/PlayMode -> 构建 -> 启动真实Player烟测 -> 收集日志/报告/哈希 -> 停子进程并释放lease。步骤设独立超时，失败不得跳到绿色构建。受控编译错误应产生编译诊断+失败状态，回滚后重建再取证；exit0不替代无Error/引用/材质检查。无GPU场景不可使用空渲染证据替代真实画面。

禁止本T02执行上述步骤。T03恢复条件：T02独立PASS；owner补齐Windows内存、质量与20:9；A00实例化完整修订契约；A02 G14签核新SHA。若版本/工具不可用，报告BLOCKED及缺项，不静默换Editor、模型或设备。
