# ADR-001：基础技术边界、坐标与时钟

版本 1.0.2；状态：候选，待 A04。依据 T02-contract-v1、T01 v1.2.0；所有运行数值仍为目标，非实测。

## 决定

采用 Unity GameObject/组件呈现与纯 C# 领域逻辑分层。NavCore 不引用 UnityEngine、渲染器、Input System、UI 或文件系统。组合根创建依赖，唯一 SimulationHost 驱动所有船的逻辑步；观察者只能读取不可变快照和事件。场景中一个可控船，压力配置另外 29 个实际运动、渲染、生成尾迹的代理。

世界中心为原点，X 向东、Z 向北、Y 向上；边界 X/Z 均为 [-1024,1024] m，边长 2048 m。Unity 1 unit = 1 m，逻辑水面 Y=0。船首局部 +Z，右舷 +X。航向 `heading_deg` 归一到 [0,360)，0=北、90=东；前向 `(sin(theta),cos(theta))`。最短角差结果属于 **(-180,180]**：先将有限输入归一到 [0,360)，令 `d = EuclideanMod(to-from,360)`，再取 `d > 180 ? d-360 : d`。恰好 180 度统一选正向：0→180 为 +180，350→10 为 +20，10→350 为 -20，180→0 为 +180。

Python 对正除数的 `%` 为欧氏模；C# `%` 是截断余数，负被除数会产生负余数，不能直接互换。C#风格等价定义如下（输入须先检查有限数；此处是接口说明，不声称已编译运行C#）：

```csharp
double EuclideanMod360(double x) {
    double r = x % 360.0;
    return r < 0.0 ? r + 360.0 : r;
}
double ShortestHeadingDelta(double from, double to) {
    double d = EuclideanMod360(EuclideanMod360(to) - EuclideanMod360(from));
    return d > 180.0 ? d - 360.0 : d;
}
```

纯逻辑参考函数为 `protocol_model.shortest_heading_delta`，回归钉住平角、跨零和反向。此修正不改变 `omega_max` 或路线转向上限 `omega_max*dt*1.05`。

距离 m、速度 m/s、加/减速度 m/s²、时间 s、角度 deg、角速度 deg/s；性能帧时 ms，禁止把逻辑 tick 当渲染帧。逻辑采用 50 Hz、dt=0.02 s（T01 授权 T02 在 30/50 Hz 中锁定），5 ticks=0.10 s。控制命令在 tick 边界提交；先处理命令/规划结果，再推进运动、安全扫掠与到达判定，最后发布快照。暂停不累计到达 tick；重入新建 session_epoch，tick 从 0 计数。

使用累计器和渲染插值，帧率下降不加大 dt、不跳过逻辑 tick；出现积压时记录 backlog，不得借慢模拟取得帧率 PASS。插值只写显示对象，永不反写导航坐标。持久化/导出用双精度数字，禁止 NaN/Infinity；Unity Transform 是呈现投影，不是存档来源。

世界为 8×8 个 256m 逻辑块：`ix=min(7,floor((x+1024)/256))`、`iz` 同理，只有已判定世界内的坐标可转换。内部边界归东/北块，最外 +1024 归第7块。水面 UV `(x+1024)/2048,(z+1024)/2048`。分块只优化渲染和空间索引；完整导航几何在会话期间常驻，LOD/摄像机剔除不可删除障碍。所有坐标交换必须标 `world_xz_m`，禁止由 localPosition 冒充世界坐标。

## 工具与版本决定

| 项目 | 架构决定 | 锁定及证据责任 |
|---|---|---|
| Editor | 使用 owner 已登记的 6000.6.6f1，禁止静默升级 | owner 输入为报告值；T03 启动前核对二进制版本、模块、许可、ProjectVersion.txt |
| 渲染 | URP，使用该 Editor 随附的 core graphics 包；项目只使用一条渲染管线 | T03 从实际 Package Manager 解析结果锁 URP/Core/ShaderGraph 精确版本及内容 SHA，当前 resolved_version=null |
| 输入 | `com.unity.inputsystem`，单一 Action 集，禁止同时启用两条输入命令来源 | T03 解析兼容稳定版本、锁 manifest/packages-lock；1.19 文档仅作 API 依据，不声称已安装 |
| 运行 UI | `com.unity.ugui` + TextMeshPro，Canvas/EventSystem 单实例 | T03 锁精确包版本；A10 实现 HUD 与中文字体引用 |
| 测试 | `com.unity.test-framework` 用于后续 EditMode/PlayMode | 精确版本与运行证据归 T03/A11；本候选只用 Python 标准库试验 |
| 相机 | 自有薄 CameraRig，无必需 Cinemachine 依赖 | T10 实现连续 pan/zoom/follow/reset |
| 寻路 | 独立平面多边形数据 + 可替换规划器，无强制 AI Navigation 包依赖 | 不以渲染 mesh/NavMeshAgent Transform 充当权威状态 |
| 桥接 | 保留冻结模板 CoplayDev/unity-mcp 标识 | commit/endpoint/能力探测当前 null；A14 在 T03 锁定，不能以本机其他工具替换后隐瞒 |

具体质量档和图形 API 不在此文冻结为已验收性能配置。建议先验证 Windows D3D11 路径，但 owner 注册的 AMD GPU/驱动、1920×1080、最低30fps、p95≤33.3ms必须保留；质量、内存和20:9仍 BLOCKED。URP 是 Editor 随附核心包，不根据营销版本猜 patch。上述选择是架构决定，兼容安装与编译结果为 NOT_RUN。

Unity 官方依据（2026-11-06查阅）：[URP兼容规则](https://docs.unity.com/en-us/engine/6000.6/manual/render-pipelines/universal-render-pipeline/requirements)说明 URP 随 Editor 提供，支持 D3D11；[UI比较](https://docs.unity.com/en-us/engine/6000.6/manual/uitoolkits/ui-system-compare)列出运行时 uGUI、Editor UI Toolkit 的适用关系；[Input System UI支持](https://docs.unity3d.com/Packages/com.unity.inputsystem@1.19/manual/UISupport.html)是输入/UI适配依据。本候选选择 uGUI 是结合小型 HUD 与 Prefab 工作流的项目决策。

## 模块依赖约束

`Contracts` 无引擎依赖；`WorldData -> Contracts`；`Navigation -> Contracts + WorldData`；`Session -> Contracts + Navigation`。`UnityAdapters -> Session + Contracts`；`Presentation -> Contracts`（船体、海水、尾迹）；`Interaction -> Contracts`（输入、HUD、相机）；`Composition` 负责注入所有模块。Editor 导出器单独 Editor assembly。没有运行模块依赖 Editor、测试、Gate 或租约服务。

世界 JSON/船型数据加载完成后以只读快照发布；无法加载、几何非法、锚点不合法时拒绝激活场景，不生成一个看似运行的默认世界。NavCore 每个船 ID 仅有一个状态实体；HUD 不保存第二套可修改状态，VisualRoot 无 Moving 等业务标志。事件从逻辑 tick 发出，订阅句柄由 SceneSession 统一释放。

接口采用 SemVer：字段/枚举/坐标/单位/行为破坏性变化升 major；仅可选附加字段升 minor；说明修正升 patch。所有构建、快照、世界导出、夹具、评审记录显式绑定接口版本及内容 SHA。同一名称不同 SHA 是不同候选。变更冻结行为须 A02/A04 审查并按 G14 重签，不能以接口版本号替代签核。
