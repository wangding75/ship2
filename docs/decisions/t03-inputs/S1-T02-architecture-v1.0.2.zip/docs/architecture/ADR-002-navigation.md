# ADR-002：单一航行状态与安全规划

接口 S1-INTERFACES/1.0.2；T01 TR-01..TR-09 保留。权威 `ShipNavigationState` 只有 Idle、Moving、Stopping、Arrived、Blocked；规划等待、错误横幅、选中标记是正交字段，不新增第六个导航状态。

## 权威数据与显示隔离

NavCore 持有 world_xz、heading、speed、state、goal、path、generation、arrival_count。NavRoot 只由适配器映射到 `(x,0,z)` 与绕Y的heading；它下面的 VisualRoot 承担 heave/pitch/roll，Meshes/LOD/帆动画均在 VisualRoot 下。海浪不得写 NavRoot，导航不得读取 VisualRoot/渲染插值的位置。选择 collider 仅用于选船，不决定可航域。运行物理引擎不能成为第二个平移积分器。

## 命令与异步规划

每条命令有 `(session_epoch,ship_id,command_id)`；CommandId 在一次会话内单调递增，重复传输同一 ID 返回同一结果、无二次副作用。按输入顺序在 tick 内处理。Stop/新目标/重入使规划 generation 递增；规划 request/result 都带 epoch、generation、map_sha、profile_sha、start_pose_tick。

MoveTo/Return 被接收后 `pending_target` 可立即供HUD显示，尚未成功规划不发 OnCommandAccepted。静止船等待时保持原状态/坐标；移动船继续已认证的安全旧路径，记录 pending。在后续路径不足以覆盖制动距离前进入受控制动，最终状态仍为 Idle（规划pending不是Blocked）。规划有有限墙钟超时，默认技术目标2秒，具体性能验证归T12；timeout是系统错误而非几何不可达，不计入20负例。

成功结果必须再次验证：版本与generation仍匹配；起点已移动时从当前姿态构造连续合法接入段并认证制动包络，不能把船跳回旧起点。若接入失败，以当前快照重新请求并持续安全制动；达到超时则拒绝/停稳，显式 PLAN_TIMEOUT。过时结果丢弃并记录事件，不能恢复已Stop的航行。Stop必须取消pending结果，即使当前静止。

同一目标的几何幂等：成功接受目标时，将已验证结果的 `map_sha/profile_sha` 绑定到活动目标的 `active_map_sha/active_profile_sha`；不能只比较请求时的当前值。Moving 且新点与活动目标距离≤0.25*R_nav、当前map/profile与上述两项绑定都相等时，才直接保持路径/速度/arrival计数，不重算、不新建实体、不追加订阅。新command_id可返回 `ALREADY_ACTIVE`，不新增到达事件身份。任一版本变化，即使新点在容差内也进入新规划请求，不以旧活动路径返回 `ALREADY_ACTIVE`；成功接受新目标后更新绑定。清空目标、Stop、恢复会话时清空绑定；过期结果不能改写绑定。未重新认证的旧版本路径不视为新版本安全路径，实际安全制动仍按上文处理，纯协议模型不模拟运动。

对于新的 command_id，同目标 pending 只有在 `pending.map_sha == map_sha` 且 `pending.profile_sha == profile_sha` 时才合并。任一哈希不同，即使目标完全相同，也先使旧 token 失效、generation 递增，再签发绑定当前两个哈希的新 token；适用于 Moving 及首次接受前的 Idle。连续 B→C→D 变化必须逐次换 token；版本稳定后的同目标请求合并到最新 token，旧 token 的 resolve 必须失败。版本按内容哈希判断：没有新请求替换 token 时，哈希变回 token 原值仍可接受；同一 command_id 的传输重放仍返回原收据，不重新激活其中已失效的 token。

活动绑定版本不变时，在远目标 pending 期间点击活动目标附近仍返回 `ALREADY_ACTIVE`，不取消该远目标，远结果仍可生效。0.25*R_nav 含边界规则不变。本补丁只收紧同目标 pending 合并的版本条件，不扩展产品语义。

## 完备转换

| 输入/条件 | Idle / Arrived / Blocked | Moving | Stopping |
|---|---|---|---|
| 合法远目标规划成功 | Moving，绑定新goal | Moving，当前pose连续接入新路 | Moving，撤销停止终态，连续再加速 |
| 合法近目标，d≤0.5R且v≤0.20 | TR-02立即Arrived，无位移；此前非Arrived才发一次OnArrived | 仍走TR-04的5 tick驻留，不直接到达 | 作为新合法命令进入Moving，再走TR-04 |
| 非法目标/无路径 | 坐标完全不变，Blocked，立即拒绝事件 | Stopping，pending_terminal=Blocked；停稳后Blocked | 保持Stopping，pending_terminal=Blocked；停稳后Blocked |
| Stop | 清目标/错误/待处理请求，Idle；幂等无位移 | Stopping，清远端path，pending_terminal=Idle | 保持Stopping，pending_terminal=Idle；显式Stop清旧拒绝终态 |
| 停稳 v≤0.05 | 不适用 | 不适用 | 精确v=0、omega=0，转pending_terminal，OnStopped一次 |
| 到达条件连续5 ticks | 不适用 | Arrived，OnArrived一次；后续不重复 | 不累计到达 |
| Return | 与MoveTo相同，目标来自唯一合法水域anchor | 连续改目标 | 连续恢复航行 |
| UI消费/拖动/未选船 | 不送入导航命令；反馈事件独立 | 不更改当前航行 | 不更改当前制动 |

TR-08的实现选择为“先Stopping再Blocked”，符合T01受控停稳后固定Blocked的语义；HUD收到拒绝事件即显示原因，不能因Stopping隐藏不可达反馈。Blocked保持到明确合法命令或Stop，不采用可选超时自动清状态。TR-02是T01对已静止且在容差内的显式快捷分支；100条航行路线的TR-04绝不因此免除5 ticks。

几何拒绝码严格保留：`OUT_OF_BOUNDS`（目标点或所需船体包络越界）、`TARGET_ON_LAND`（点在陆地内）、`CLEARANCE_INSUFFICIENT`（水面净空不足）、`NO_PATH_FOUND`（局部合法但无连通合法路径）。检验顺序为有限数/世界界、陆地、局部净空、连通路径。`INVALID_NUMBER`、`MAP_MISMATCH`、`PLAN_TIMEOUT`、`SAFETY_INVARIANT_BROKEN`是独立系统错误，不伪装成通过的几何负例。

## 运动与安全不变量

固定dt内线速度变化≤所用a*dt、最短航向角变化≤omega_max*dt；保持position连续。沿曲率曲线执行，v应满足 `v * abs(curvature) <= omega_max*pi/180`；不能把折线节点直接转成瞬间转向。路径平滑后必须重新做包络净空检查，不允许只检原折线。加减速与速度上限采用T01三船型原值，接口只复制，不借设计调整阈值。

每一步先预测整个船体扫掠包络，再提交位置。以R_nav圆盘扫掠作为T01必测下限，同时用实际船体胶囊包络覆盖长船首尾（asset-contract定义）。扫掠需包含转向期间的包络，不能只检两个端点。世界边界内含整个代理。接触净空d_signed≥0，内部数值容差仅允许更保守拒绝，绝不接受负净空。

每次规划/推进要持有一条从当前pose可制动的安全走廊；可用前进距离至少覆盖 `v²/(2*a_stop)+v*dt` 以及当前包络。Stop清远端业务路点，但保留短段已认证制动走廊；切线遇岸时沿该走廊连续转向减速。新路径不能承接当前速度/航向时保留旧走廊制动，不能强制急停或穿岸接入。技术试验不证明生产几何或动力学已实现；T12必须验证贴岸/急转弯中停止与改目标。

若运行时发现本应存在的制动走廊失效（例如数据损坏），拒绝提交穿岸位置并记录 `SAFETY_INVARIANT_BROKEN`，停止会话测试，记FAIL；不得以瞬移安全点、强制速度归零后声称连续运动PASS。S1地图运行期间不可原地热改；换图使用受控重入，世代整体失效。

到达计数每tick检查 `d<=0.50*R_nav && v<=0.20`，任一不满足清零；首次5记到达。进圈前按制动距离减速，末速归零仍满足减速度界（v≤0.05的T01归零例外）。Arrived只保留目标/到达结果，无活动路径；不把坐标吸附到目标。事件携带command/goal身份、误差、tick与is_port_anchor，便于检查恰好一次。

本候选的Python参考模型验证命令世代、状态、事件与到达防抖；不包含A*、曲率跟随或生产碰撞内核，不用于证明S1-AC05或T12完成。
