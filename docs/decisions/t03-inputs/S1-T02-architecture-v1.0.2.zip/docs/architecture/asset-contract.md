# 世界、资产与工程目录契约

版本1.0.0；本节目录是未来实现落点，不扩大各任务allowed_paths。A03只交付设计。各角色写入前仍以其已签核实例化契约为准。

## 目录和程序集

工程预定根 `client/UnityProject/`。`Assets/Game/` 下：`Scripts/Contracts/`、`Scripts/WorldData/`、`Scripts/Navigation/`、`Scripts/Session/`、`Scripts/UnityAdapters/`、`Scripts/Presentation/`、`Scripts/Interaction/`、`Scripts/Composition/`、`Editor/`；每个运行模块一个同名 `S1.<Module>.asmdef`，按ADR-001单向依赖。资产分到 `Art/Ships/`、`Art/Islands/`、`Art/Water/`、`Art/Wakes/`、`Prefabs/Ships/`、`Prefabs/Islands/`、`Prefabs/UI/`、`Data/World/`、`Data/Ships/`、`Scenes/`、`Settings/`。测试独立 `Tests/EditMode/`、`Tests/PlayMode/`，不得依赖Editor实现运行功能。

导出规格在 `specs/interfaces/`，冻结测试夹具由A11在其授权目录维护。原始美术源与导出资产一一映射，资产记录 author、source_license、source_sha、exporter_version、export_settings_sha、import_settings_sha，不默认任何外部素材获许可。

GUID规则：Unity导入生成的资产/目录 `.meta` 与文件同批入库；移动/重命名同时保留meta，删除也成对。禁止重生成现有GUID、跨资源复制同GUID或手工伪造GUID。Prefab/材质/动画引用以GUID/fileID保存，业务身份用稳定字符串ID，绝不把display_name或Hierarchy路径当存档ID。没有真实Unity导入，本候选不造meta或Prefab。Unity官方说明 [.meta保存唯一ID与导入设置](https://docs.unity.com/en-us/engine/6000.6/manual/assets-and-media/import-assets/asset-metadata)；这些项目约束用于保护引用和可复现导入。

所有共享材质只读，实例差异用每实例参数；禁止每帧创建Material。Prefab根scale=(1,1,1)，导出单位米，旋转/尺度烘焙，避免负尺度。实例允许平面平移与Y旋转，岛型需缩放时先烘焙进几何数据并重导出；运行不能只缩放可视网格而不变导航边界。

## 船Prefab逻辑结构

`ShipRoot`含业务ShipId与Nav适配器，逻辑基准位于水线几何中心；子节点 `SelectionProxy`（选择用途，不积分运动）、`VisualRoot`（仅heave/pitch/roll）、`VisualRoot/Hull`、`VisualRoot/Masts`、`VisualRoot/Sails`、`VisualRoot/LODGroup`、`VisualRoot/WakeSocket`。模型三个LOD共享水线、枢轴、朝向与尾迹挂点；LOD不能更换ShipId或逻辑状态。

船型Profile字段保留T01轻/中/重船长16/24/32m与R_nav=4.5/6.5/8m。R_nav并不等于长船半长：半径8m的圆无法覆盖32m全船。采用轴向胶囊补足全船包络，半径=R_nav、中心线半长 `max(0,length/2-R_nav)`，并用实际网格水平包络核验（有更宽/长部件则显式重评Profile，不能悄悄减小碰撞体）。T01圆盘扫掠断言保留，胶囊的平移与旋转扫掠另检；窄通道用2.5～6R_nav宽度口径不变。实际船型几何尚未产出，包络覆盖是T06/T11的验收责任，不在此伪报PASS。

WakeSocket是真实船尾局部米坐标；计算世界采样时使用逻辑heading/position + socket平面偏移，显示高度可取海面值。视觉摇晃不改变采样的导航轨迹。碰撞代理不含桅杆高空投影造成无关阻塞，但水线船体首尾与宽度必须被覆盖。

## 世界导出数据

WorldNavigationData包含schema_version、world_id、scenario_seed（uint64十进制字符串，避免JSON消费者53位精度损失）、generator_version、geometry_sha、bounds、water_y、3种岛型标识、12个实例（稳定ID、原型、平面pose、source_guid）、障碍多边形、浅滩禁航区、岸线可视数据引用、唯一port与anchor。具体岛位置、港口建筑、船型网格不是T02产物；示例数据明确标synthetic，不进入生产地图或100路线夹具。

多边形规则：世界米XZ，外环逆时针、孔环顺时针（以XZ的shoelace正号约定），至少3个不同顶点，首尾不重复、无自交、无零长边；坐标有限。障碍solid包含外环内部减孔内部，边界视为障碍边缘。land/shallow等分类独立；外部可航边界与所有solid作差得到water域。用于导航、岸线泡沫和深度过渡的导出都绑定同一个geometry_sha，LOD只能改变表现细分，不能改底图。

geometry_sha对规定内容字段进行UTF-8、键排序、紧凑JSON的SHA256，字段中排除自身sha；生成器先将空间值量化为1e-5m整数再导出（禁止读回Unity float重新累计）。实例顺序按ID、轮廓按ID稳定排序，seed+generator+源资产SHA+配置SHA决定输出；随机数算法与版本写入generator_version，不依赖遍历时序/全局随机状态。A08以两次独立重建导出验证字节一致及≤1e-5m误差，A13独立几何复核。

锚点是可航水域坐标而非码头mesh枢轴。必须有且仅一个，距陆地/禁航区≥1.5*R_nav,max=12m，完整最大船包络在world内，并与起始/路线主连通水域相连。若胶囊艏艉要求更大安全空间，额外验证所有允许停泊heading，不降低12m下限。地标与锚点使用不同ID与坐标，不能将地标Transform拖到岸上后让返航目标随之移动。找不到合法锚点则世界导出FAIL，禁止静默吸附最近水点。

资源装配检查设计：丢失脚本/引用、重复GUID、非正尺度、空LOD、相同网格冒充全部LOD、材质不兼容、socket不在船尾、NavRoot受Animator写入、可视海岸与导航sha不一致均拒绝候选。材质/面数具体预算沿用后续经签核T05/T06，不在本文件编造数值。
