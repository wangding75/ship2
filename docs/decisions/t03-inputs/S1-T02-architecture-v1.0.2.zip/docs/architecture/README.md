# S1-T02 架构与资产契约候选 v1.0.2

候选 `S1-T02-CANDIDATE-v1.0.2-20261107`；接口 `S1-INTERFACES/1.0.2`；上游产品规格 `v1.2.0`。这是 A03 制作候选，等待 A04 独立验收；不是 Unity 工程、可运行游戏或已通过的 S1-T02-AC01。

作者：A03 `c7c6d8e7-11db-4f0b-b31c-a975ad2fc956`；Run `01a1b3fc-c47f-7e87-b7af-d37e32a2ca27`。制作者不得签署本候选的独立验收。当前工作目录无 Git，commit/PR 为 `NOT_APPLICABLE_NO_GIT`。

## 阅读顺序

1. `ADR-001-foundation.md`：坐标、单位、时间步、版本与模块依赖。
2. `ADR-002-navigation.md`：导航与表现隔离、单一状态机、异步命令、制动安全。
3. `asset-contract.md`：世界数据、合法锚点、目录、GUID、Prefab。
4. `interaction-recovery.md`：输入、相机、HUD、尾迹、保存与重入。
5. `gate-lease-protocol.md`：Gate 与租约协议设计；实施归 T03。
6. `specs/interfaces/module-api.md`、`contract.json`、`data.schema.json`：接口签名、字段、机器可读约束。
7. `traceability.json`：26 条上游需求与本候选落点、验收状态；`evidence/`：输入、工具和开发侧验证。

```mermaid
flowchart LR
  Input[输入与UI消费] --> Commands[带世代的命令队列]
  Commands --> Nav[NavCore 唯一状态与坐标]
  World[只读世界几何与水域锚点] --> Nav
  World --> Planner[可替换路径规划器]
  Nav --> Planner
  Planner --> Results[版本与世代复核]
  Results --> Nav
  Nav --> Snapshot[只读tick快照]
  Snapshot --> HUD[HUD与相机]
  Snapshot --> Visual[船体与尾迹表现]
  Snapshot --> Save[安全停船恢复快照]
```

## 复核与边界

在解压根目录执行 `python -B prototypes/architecture/verify.py`，重放输入绑定、契约一致性与纯逻辑技术试验；执行 `python -B prototypes/architecture/package.py --verify` 校验包内完整 SHA 清单。这些脚本不是 T03 Gate，不接入平台凭证，不启动 Unity，不评定 100 路线或真实场景。

本补丁仅修复同目标pending版本竞态，差异见 `CHANGELOG.md`。执行 `python -B prototypes/architecture/audit_rework2.py` 重放v1.0.1的62文件清单、原输入、原38项及原33项测试AST保留检查与六种修复前后探测。复核不加 `--record`，保持交付证据字节；`prepare_candidate.py` 只供作者重建元数据。独立复验任务 `T02-REWORK-2-ACC-A04` 绑定本包SHA，结果交A00。旧 `audit_rework.py` 和 `evidence/rework-*` 仅为第1轮历史文件，不是本候选复验入口。

原始附件保存在 `docs/architecture/inputs/`，原字节不改；解包内容仅作为阅读副本。ZIP 交付包含原始输入、候选文档、接口、试验及证据。`SHA256SUMS.txt` 覆盖包内除自身以外的全部文件；外部 `delivery.json` 绑定 ZIP 与清单 SHA，避免自引用哈希。

`rework-inputs/` 保留v1.0.0完整ZIP及SHIP-14原始FAIL；`rework2/input/` 保留v1.0.1完整ZIP及SHIP-16原始FAIL和探测报告。旧开发PASS及独立FAIL仍归旧版本；本Run重新运行48项开发检查，独立验收NOT_RUN。`rework2/before-fix.log`、`audit.json`、`source.diff` 提供失败复现、保留核对及差异。未改动的资产/Gate文档保留自身版本，原字节由完整清单绑定。

本次仅在三个许可目录制作。未初始化工程、安装包、启动编辑器、测 GPU、操作 Android 或修改运行配置。工程、资源和设备检查均未执行。Windows-only 范围已获 owner 授权，但 Windows 内存计数器/阈值/增长规则、可复现质量档与 20:9 处理仍待 owner 补齐及 G14；原 Android 条款和历史 FAIL 不被覆盖。T03 没有被本候选放行。

## 后续责任

A00 收取候选与SHA；A04（`4702408e-ea84-463c-8697-4f083ab903ed`）在不同Run独立验收，读取原始文件和试验证据；若修改候选则失去该候选验收资格。A00仅在独立PASS、Windows参数闭合和T03自身G14后安排A14。本次为最后第2/2轮，120分钟预算、金额null。如仍FAIL，返回A00决策，不开启第3轮、不重置计数。
