# 输入、相机、尾迹与恢复契约

接口1.0.2。本文件规定数据和生命周期，不实现Canvas/Editor工具。

## 输入与HUD

InputRouter以pointer_id跟踪一整次按下/拖动/抬起。UI在按下时消费后锁定到抬起，即使指针拖离面板也不下发世界命令；从世界拖入UI同样取消点击。手势超过10px为拖动（T01建议起值），多指或缩放后本手势不再是点击。只有未消费、未拖动的抬起才选择船或求目标。使用射线与静态平面Y=0求交；平行、相机后方、非有限交点拒绝，不用海浪mesh的瞬时高度或碰撞法线计算目标。

顺序为UI消费 -> 手势分类 -> 可控船选择 -> 已选船水面目标 -> 命令队列。未选船点击只发 `CommandIgnored_NoShipSelected`；未选中意味着没有新增命令，不能用此分支重置正在航行的船。压力船不能被夺权。UI Stop/Return/Reset使用显式动作，不再穿透同一次指针为MoveTo。每个动作只由一个router发命令；EventSystem和InputSystemUIInputModule的适配由A10在锁定包版本后实施。基于[官方UI支持文档](https://docs.unity3d.com/Packages/com.unity.inputsystem@1.19/manual/UISupport.html)，UI指针处理和游戏动作需要协调；本项目选择对整次手势记录消费状态，不只在输入回调瞬间查询UI。

HUD只读NavigationSnapshot：ship_name/type、state、active/pending目标、remaining_path_m、speed_mps、feedback。remaining_path_m是当前位置沿合法已接受路径到终点的剩余弧长；pending期间显示“规划中”并区分新目标和旧活动路径，不能用新目标配旧距离。无目标为null/显示“—”，到达显示≤D_arr；停止立即清目标，Blocked保留失败请求供反馈但非活动路径。事件原因不被UI文本覆盖。船型切换仅在静止且新Profile完整包络合法时执行，原位置保持，仍只有1个主船；不合法拒绝，不能先删旧船再生成失败。

鼠标与触控映射进入同一意图接口；Windows无触屏不得声称物理触控已测。16:9、4:3与20:9的原要求保留，20:9的Windows替代处理待owner/G14，不能默认为删除。UI内容必须在safeArea内、中央至少75%留作观察点选；各HUD按钮和面板背景分别连续20次点击应产生0个额外水面移动命令。此处为测试契约，未实跑。

## CameraRig

CameraState包含lookat_xz_m、height_m、pitch_deg、yaw_deg、follow_ship_id（可null）。默认yaw=0、pitch=55度（owner/冻结目标±2）、height=85m（T01建议），近/远35/220m也是建议，不是图4测量。渲染相机从lookat沿水平forward反向偏移 `height/tan(pitch)`，Y=height，朝向lookat；镜头不反写船坐标。pan在XZ平面求两帧视线交点差，解除follow；zoom连续且限制[35,220]m，reset恢复55/85与follow，完成后中心距船≤0.1m。lookat clamp到world边界，禁止越界漂移。复位期间新pan取消旧复位插值，避免两套camera控制器争写。

镜头查询navigation snapshot而非摇晃后的VisualRoot。图4观察仅为定性倾斜俯视；HUD、港口建筑、三船并列细节为null。具体水色/材质由A05/A08制作、A07独立判断。

## WakeRenderer

接收 `(session_epoch,ship_id,tick,stern_world_xz,height,speed,state)`，样本一旦创建固定在世界空间，不挂在移动/旋转的船父节点。输出世界水面上的尾迹点带，弯曲按历史世界点插值，插值段不得越过岸线；离开水域的宽带需裁剪而非盖住陆地。state为Arrived/Idle/Blocked或speed≤0.05时停止新点，Stopping仍随非零速度生成。LOD仅改变显示密度，保留世界点和池槽身份，防止切换跳位。

技术起值采样10Hz、移动寿命6s、停船残迹4s（分别位于T01建议4～8s、3～6s内）。每船固定64个采样槽（ceil(10*6)+4），30船共1920槽；超量回收最老槽并记录overflow，而非扩容或静默GC。这些是T02设计容量，后续T14性能证据前不声称够用；改采样/寿命需同步调整容量并审查。启动预热创建所有节点/材质，稳定运行不得持续新建；dispose释放全部池/订阅，重入不继承尾迹。

## MinimalSessionSnapshot

选择T01允许的“保存位置、停船恢复”分支，不恢复活动航程。保存版本、world_id/geometry_sha、profile_sha、scenario_seed(uint64十进制串)、ship_type_id、ship_position_xz_m、ship_heading_deg、state_before_save、camera字段及payload_sha。navigation_mode_on_restore固定 `SAFE_IDLE`；不保存旧path、速度、事件订阅或pending任务，active_target_xz不作为续航指令。

保存从一个完整逻辑tick捕获位置/航向/镜头，写临时文件、flush成功后原子替换最终文件；失败保留上次有效快照并反馈SAVE_FAILED。校验结构、major版本、内容sha、世界和Profile绑定、seed、有限数字、位置完整包络合法性后才恢复。不能解析/绑定不匹配/位置非法：返回RestoreRejected和原因，保持旧场景（若无旧场景则显示恢复错误）；由显式ColdReset选择港口初始化，绝不静默丢弃存档后算恢复成功。

状态恢复表：保存前Moving/Stopping -> 在保存位置Idle，速度0；保存前Idle/Arrived/Blocked -> 保存位置Idle，若在合法港口容差内则Arrived（这是恢复初始化，不发新的OnArrived）。ColdReset/没有历史快照 -> 精确港口anchor、Idle、速度0、默认相机。为保持保存的camera中心，恢复先恢复自由观察，follow_ship_id为null；用户随后Reset开启跟随。恢复位置/航向/镜头字段误差限分别≤0.01m、≤0.1deg、lookat≤0.05m、height≤0.05m、pitch≤0.1deg，航向比较使用最短角差。

SceneSession生命周期：关闭输入 -> 取消planner并递增epoch -> 取消全部subscription handles -> dispose尾迹/船/场景对象 -> 载入并校验世界/快照 -> 创建唯一实体与表现 -> 绑定一次订阅 -> 发布Ready -> 开启输入。失败事务不得留下半套新实体；epoch使旧异步回调无效。20次重入每次记录player=1、stress=29（压力模式）、orphan_wake=0、subscription counts、单动作callback=1；初次/末次根对象数差=0。纯逻辑恢复试验不等同Unity场景重入测试。
