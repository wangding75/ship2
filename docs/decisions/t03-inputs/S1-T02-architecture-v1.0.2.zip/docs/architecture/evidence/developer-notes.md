﻿# A03 第2/2轮返工开发侧验证

候选 S1-T02-CANDIDATE-v1.0.2-20261107；接口 S1-INTERFACES/1.0.2；测试 S1-T02-DEV/1.0.2。作者A03，Run 01a1b3fc-c47f-7e87-b7af-d37e32a2ca27。以下是开发侧记录，独立验收NOT_RUN。

- FAIL（修复前保留）：新增10项回归连同原38项作用于v1.0.1模型，运行48项退出1；39–44及48暴露同目标pending版本竞态，连续变化subTest累计25个失败报告；原38项通过。见rework2/before-fix.log。
- PASS：python -B prototypes/architecture/verify.py --record 实跑48项，退出0。39–44覆盖Moving/Idle与map/profile/二者变化、连续变化、每轮重复请求合并、旧token拒绝、新token成功及活动绑定不被旧结果覆盖。45–48保护同版本合并、内容SHA回转、三种半径0.25R含边界和传输重放行为。
- PASS：python -B prototypes/architecture/audit_rework2.py --record 核对v1.0.1 ZIP及62条旧清单、原38项/最初33项测试AST、原输入字节、历史FAIL、接口仅版本与pending规则改变；六种竞态均在旧实现失败、新实现通过。见rework2/audit.json与source.diff。
- PASS：当前session turn_context为gpt-6-astra/high；工具及无Git探针由本Run重新采集，见runtime.json。未静默换模型。提交/PR不适用；未初始化Git。

原38项包括26条需求原文、冻结参数、100合法路线与至少20负例配额、Stop/改目标/恢复/锚点和角差。配额检查不是实际航线运行。observe_tick注入pose/speed；矩形圆盘实验不是实际岛屿、多边形胶囊扫掠或运动积分。C#示例本Run未编译；SHIP-16的C#历史运行不搬作当前证据。

| 检查 | 状态 | 后续责任 |
|---|---|---|
| S1-T02-AC01独立验收 | NOT_RUN | A04在T02-REWORK-2-ACC-A04读取新SHA候选，结果回A00 |
| C#/Unity/真实路线/触控/视觉/GPU/性能/Android | NOT_RUN | 后续授权任务及独立验收 |
| 正式Gate及资源租约实现 | NOT_RUN | T03；本候选仅协议设计 |
| 完整JSON Schema标准校验 | NOT_RUN | jsonschema未安装，未获准安装；仅本地引用检查 |
| Windows内存/质量档/20:9最终契约 | BLOCKED | owner补参数，A00修订，A02 G14 |

图4来源、55度正负2冻结目标、85m建议及HUD/港口/三船未知项沿用原输入。Windows草案effective=false，历史Android条款、原SHIP-14/SHIP-16 FAIL保留。T03未放行；若本轮独立复验仍失败，回A00，不开第3轮。最终阶段决定仍归A15。
